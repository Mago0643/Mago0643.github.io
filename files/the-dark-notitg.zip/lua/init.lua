xero()
setupAftSprite(ScreenAFT, ScreenSprite)
ScreenSprite:diffuse(1,0,0,0):zoom(1):vibrate()
lyrics:xy(scx,scy + 100):diffuse(0,1,0,1):zoom(0.75);
score1:zoom(.25):xy(scx,sh+50)
score2:zoom(.24):xy(scx,sh-75):hidden(1)
score3:zoom(.24):xy(scx,sh-75):hidden(1)
score4:zoom(.24):xy(scx,sh-75):hidden(1)
score5:zoom(.24):xy(scx,sh-75):hidden(1)
score6:zoom(.24):xy(scx,sh-75):hidden(1)
score7:zoom(.24):xy(scx,sh-75):hidden(1)
score8:zoom(.24):xy(scx,sh-75):hidden(1)
setupAftSprite(GlitchAFT, GlitchSprite);
Glitch = GlitchSprite:GetShader();
Glitch:uniform1f('amp', 0);
setupAftSprite(AbbAFT, AbbSprite);
Abberation = AbbSprite:GetShader();
Abberation:uniform1f('DISTORTION_AMOUNT', 0);
setupAftSprite(BloomAFT, BloomSprite);
Bloom = BloomSprite:GetShader();
Bloom:uniform1f('intensity', 0)