-- player proxies
for pn = 1, #PP do
	PP[pn]:SetTarget(P[pn])
	P[pn]:hidden(1)
end

-- judgment proxies
for pn = 1, 2 do
	local judgment = P[pn]("Judgment")
	judgment:sleep(9e9)
	judgment:hidden(1)
	PJ[pn]:SetTarget(judgment)
	PJ[pn]:xy(scx * (pn-0.5), scy)
end

-- combo proxies
for pn = 1, 2 do
	local combo = P[pn]("Combo")
	combo:sleep(9e9)
	combo:hidden(1)
	PC[pn]:SetTarget(combo)
	PC[pn]:xy(scx * (pn-0.5), scy)
end

-- your code goes here here:
initMods();
setdefault {100, 'modtimer', 100, 'disablemines'}
loadfile(xero.dir..'lua/init.lua')()

local function camZoom(beat, len, ease, zoom)
	func_ease {beat, len, ease, zoom, 1, "GlitchSprite:zoom"}
end

local function glitch(beat, len, ease, amp, zoom)
	func_ease {beat, len, ease, amp, 0, function(p)
		Glitch:uniform1f('amp', p);
	end}
	camZoom(beat, len, ease, zoom);
	func_ease {beat, len, ease, amp * 100, 0, function(p)
		Abberation:uniform1f('DISTORTION_AMOUNT', p);
	end}
	func_ease {beat, len, ease, .5, 0, function(p) Bloom:uniform1f('intensity', p) end}
	if beat >= 532 then
		func_ease {beat, len*2, ease, 2, 0, 'ScreenSprite:diffusealpha'}
		func_ease {beat, len, ease, 1.2, 0.98, 'ScreenSprite:zoom'}
		func_ease {beat, len*2, ease, 1, 0, function(p) BloomSprite:diffuse(1,1-p,1-p,1) end}
	end
end

func_ease {184, 4, outExpo, sh+50, sh-75, 'score1:y'}
func {200.5, function()
	score1:hidden(1)
	score2:hidden(0)
end}
func {218, function()
	score2:hidden(1)
	score3:hidden(0)
end}
func {232, function()
	score3:hidden(1);
	score4:hidden(0);
end}
func {250, function()
	score4:hidden(1);
	score5:hidden(0)
end}
func {280, function()
	score6:hidden(0)
	score5:hidden(1)
end}
func {296, function()
	score6:hidden(1)
	score7:hidden(0)
end}
func {306, function()
	score7:hidden(1)
	score8:hidden(0)
end}
func_ease {314, 4, inBack, sh-75, sh+50, 'score8:y'}
--[[set {187.5, 200, 'beat', -50, 'beatmult'}
set {313.5, 0, 'beat', 0, 'beatmult'}]]

for i = 146, 158, 4 do
	glitch(i, 4, outExpo, 0.01, 1.075);
end
glitch(164, 4, outExpo, 0.01, 1.075);

local godbeats = loadfile(xero.dir..'lua/godbeats.lua')();
local fuck = loadfile(xero.dir..'lua/fuck.lua')();
for _,v in ipairs(godbeats) do
	glitch(v[1], 4, outExpo, 0.01, 1.075)
	set {v[1], -10, 'tiny'}
	ease {v[1], 4, outExpo, 0, 'tiny'}
end

for _,v in ipairs(fuck) do
	local even = _ % 2 == 0;
	glitch(v[1], 2, outExpo, 0.025, 1.1)
	set {v[1], even and 200 or -200, 'tipsy', even and 200 or -200, 'drunk'}
	ease {v[1], 2, outExpo, 0, 'tipsy', 0, 'drunk'}
end

ease {134, 2, inExpo, 100, 'drunk'}
ease {140, 1.5, inExpo, 500, 'x', -100, 'flip', -500, 'drunk'}
ease {141.5, 2, outExpo, 0, 'drunk', 0, 'x', 0, 'flip'}

glitch(597, 8, outExpo, 0.025, 1.075)

set {502.5, 200, 'beat'}
set {514.5, 0, 'beat'}
ease {515, 2, outExpo, 100, 'drunk'}
ease {517, 2, inExpo, 0, 'drunk'}
set {518.5, 200, 'beat'}
set {564.5, 0, 'beat'}

for i = 503, 531 do
	if i ~= 516 and i ~= 517 and i ~= 518 then
		camZoom(i, 2, outExpo, 1.075)
	end
end

set {530.5, 0, 'beat'}
set {532.5, 200, 'beat'}
ease {531, 1, outExpo, -100, 'drunk'}
ease {532, 1, inExpo, 0, 'drunk'}
ease {565, 2, outExpo, 20, 'digital', 20, 'sawtooth'}
ease {597, 4, outExpo, 0, 'digital', 0, 'sawtooth'}
ease {617.5, 4, outQuad, -200, 'flip', math.rad(-180)*100, 'confusionoffset'}
ease {617.5, 2, inBack, 700, 'y'}

local data = {
	{5.5, "But you have to keep going,"},
	{12, "Keep moving on."},
	{14, "...and don't you ever look back."},
	{16, ""}
};
for _,v in ipairs(data) do
	local text = v[2];
	func {v[1], function()
		lyrics:settext(text)
	end}
end

-- does SM5's speed linear mult thing
if not P1:IsUsingCMod() or not P2:IsUsingCMod() then
	loadfile(xero.dir.."lua/speedtable.lua")()
	local player_speed = {P1:GetXMod(), P2:GetXMod()}
	for _,v in ipairs(speedtable) do
		if P1 and not P1:IsUsingCMod() then
			ease {v.beat, v.length, linear, player_speed[1] * v.mult, 'xmod', plr=1}
		end
		if P2 and not P2:IsUsingCMod() then
			ease {v.beat, v.length, linear, player_speed[2] * v.mult, 'xmod', plr=2}
		end
	end
end