import os

path = os.path.dirname(__file__) + '\\'

piss = open(path+'text.txt', 'r')
data = piss.read().replace('\n', '').replace(',', '=')
piss.close()

table = data.split('=')
lua = "return {\n"
for i in range(0,len(table)):
  if i % 4 == 0:
    beat = table[i]
    speed = table[i+1]
    length = table[i+2]

    lua += "\t{beat=" + str(beat) + ",mult=" + str(speed) + ",length=" + str(length) + "},\n"
lua += "}"

luaFile = open('lua/ConvertedLua.lua', 'w+')
luaFile.write(lua)
luaFile.close()