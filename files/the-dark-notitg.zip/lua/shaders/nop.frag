#version 120

varying vec2 imageCoord;
uniform vec2 textureSize;
varying vec2 textureCoord;
uniform vec2 imageSize;
uniform sampler2D sampler0;
uniform float time;
varying vec4 color;

void main()
{
  vec2 uv = imageCoord;
  vec3 col = texture2D(sampler0, uv).rgb;
  gl_FragColor = vec4(col, 1.0) * color;
}