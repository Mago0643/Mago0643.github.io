#version 120

varying vec2 imageCoord;
uniform vec2 textureSize;
varying vec2 textureCoord;
uniform vec2 imageSize;
uniform sampler2D sampler0;
uniform float time;
varying vec4 color;
uniform float intensity;

void main()
{
  vec4 sum = vec4(0);
  vec2 texcoord = textureCoord;
  float blurSize = 1.0/512.0;
  int j;
  int i;

  //thank you! http://www.gamerendering.com/2008/10/11/gaussian-blur-filter-shader/ for the 
  //blur tutorial
  // blur in y (vertical)
  // take nine samples, with the distance blurSize between them
  sum += texture2D(sampler0, vec2(texcoord.x - 4.0*blurSize, texcoord.y)) * 0.05;
  sum += texture2D(sampler0, vec2(texcoord.x - 3.0*blurSize, texcoord.y)) * 0.09;
  sum += texture2D(sampler0, vec2(texcoord.x - 2.0*blurSize, texcoord.y)) * 0.12;
  sum += texture2D(sampler0, vec2(texcoord.x - blurSize, texcoord.y)) * 0.15;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y)) * 0.16;
  sum += texture2D(sampler0, vec2(texcoord.x + blurSize, texcoord.y)) * 0.15;
  sum += texture2D(sampler0, vec2(texcoord.x + 2.0*blurSize, texcoord.y)) * 0.12;
  sum += texture2D(sampler0, vec2(texcoord.x + 3.0*blurSize, texcoord.y)) * 0.09;
  sum += texture2D(sampler0, vec2(texcoord.x + 4.0*blurSize, texcoord.y)) * 0.05;

  // blur in y (vertical)
  // take nine samples, with the distance blurSize between them
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y - 4.0*blurSize)) * 0.05;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y - 3.0*blurSize)) * 0.09;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y - 2.0*blurSize)) * 0.12;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y - blurSize)) * 0.15;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y)) * 0.16;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y + blurSize)) * 0.15;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y + 2.0*blurSize)) * 0.12;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y + 3.0*blurSize)) * 0.09;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y + 4.0*blurSize)) * 0.05;

  //increase blur with intensity!
  gl_FragColor = sum*intensity + texture2D(sampler0, texcoord) * color;
}