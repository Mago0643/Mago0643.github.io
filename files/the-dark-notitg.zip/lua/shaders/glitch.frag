#version 120

varying vec2 imageCoord;
uniform vec2 textureSize;
varying vec2 textureCoord;
uniform vec2 imageSize;
uniform sampler2D sampler0;
uniform float time;
varying vec4 color;

uniform float amp = 0.01;
float random (vec2 st) {
  return fract(sin(dot(st.xy,
                      vec2(12.9898,78.233)))*
    43758.5453123);
}
void main()
{
  vec2 uv = textureCoord;
  vec3 col = vec3(0.0);
  col.r = texture2D(sampler0, fract(vec2(uv.x - amp - (random(uv) * amp), uv.y))).r;
  col.g = texture2D(sampler0, fract(uv)).g;
  col.b = texture2D(sampler0, fract(vec2(uv.x + amp + (random(uv) * amp), uv.y))).b;
  gl_FragColor = vec4(col, 1.0) * color;
}