if not P1 or not P2 then
	SCREENMAN:SystemMessage("Two Player Mode Required") -- Report the error to the user
	GAMESTATE:FinishSong() -- Force end the song
	return
end

-- player proxies
for pn = 1, #PP do
	PP[pn]:SetTarget(P[pn])
	P[pn]:hidden(1)
end

-- judgment proxies
for pn = 1, 2 do
	local judgment = P[pn]("Judgment")
	judgment:sleep(9e9)
	judgment:hidden(1)
	PJ[pn]:SetTarget(judgment)
	PJ[pn]:xy(scx * (pn-0.5), sh-20)
end

-- combo proxies
for pn = 1, 2 do
	local combo = P[pn]("Combo")
	combo:sleep(9e9)
	combo:hidden(1)
end

local twoPlayers = false;
local padChart = false;
if curDifficulty == Difficulty.DIFFICULTY_HARD then -- one player pad chart
	padChart = true;
elseif curDifficulty == Difficulty.DIFFICULTY_CHALLENGE then -- two player keyboard chart
	twoPlayers = true;
elseif curDifficulty == Difficulty.DIFFICULTY_EDIT then -- two player pad chart
	twoPlayers = true;
	padChart = true;
end

if not twoPlayers then
	P3:SetAwake(true)
	P3:hidden(0)
	P3:GetChild("Judgment"):hidden(1)
	P3:GetChild("Combo"):hidden(1)
	P3:SetNoteData(padChart and 3 or 2);

	for pn = 1, 2 do
		P[pn]:x(scx + (scx/2))
		PJ[pn]:x((scx + scx / 2) + (80 * scale(pn, 1, 2, -1, 1)))
	end
	P3:x(scx/2)
	plr = {1,2,3}
else
	P1:SetNoteData(padChart and 3 or 2);
	P2:SetNoteData(padChart and 1 or 0);
	PP[3]:hidden(1)

	LeftPerson:diffuse(0.9,0.9,1,1) -- blue stop signs
	RightPerson:diffuse(1,.9,.9,1) -- red stop signs
end

func {3.5, 'MESSAGEMAN:Broadcast', 'Clover_PowerDance'}
func {67.5, 'MESSAGEMAN:Broadcast', 'Clover_PowerDance'}

LeftPerson:zoom(.3):xy(scx/2+scx/10,scy+125);
RightPerson:zoom(.3):xy(scx/2+scx-(scx/10), scy+125)
LeftPersonBox:zoom(.625):xy(scx*.75, 130):hidden(1);
RightPersonBox:zoom(.625):xy(sw-(scx*.5), 130):zoom2(0);
BothTalkBox:zoom(.575):xy(scx+25,150):diffusealpha(0);

local aspect = math.floor((dw/dh)*100)/100
if aspect == 1.33 then -- 4:3
	BothTalkBox:zoom(.5)
end

YouText:shadowlength(0);
YouText:xy(RightPerson:GetX(), sh - 15);

P1Text:shadowlength(0);
P1Text:xy(LeftPerson:GetX(), sh - 15)
P1Text:diffuse(0.8, 0.8, 1, 1);
if twoPlayers then
	YouText:settext("P2")
	YouText:diffuse(1, 0.8, 0.8, 1)

	func_ease {20, 8, inOutQuad, 1, 0, 'P1Text:diffusealpha'}
else
	P1Text:hidden(1);
end
func_ease {20, 8, inOutQuad, 1, 0, 'YouText:diffusealpha'}

initMods(false);
setupAFT(RainbowAFT, RainbowSpr)
setupAFT(BloomAFT, BloomSpr)
local bloomShader = BloomSpr:GetShader()
aux {'bloom'}
node {'bloom', function(p)
	bloomShader:uniform1f('strength', p)
end}

RainbowSpr:rainbow():effectclock('beat'):effectperiod(4)
RainbowSpr:diffusealpha(0)
setdefault {3.5, 'xmod', 100, 'stealthpastreceptors', 100, 'dizzyholds', 300, 'arrowcull', 100, 'hidemines', 100, 'disablemines', -100, 'drawsizeback', -1, 'czoom', 100, 'receptorzbuffer'}
for i = 0, 2 do
	add {i, 2, outExpo, .25, 'czoom'}
end
ease {3, 1, inExpo, 0, 'czoom'}
func_ease {3, 2, outExpo, 180, 0, 'Camera:rotationz'}

set {3.5, 100, 'beat'}
set {0, 100, 'sudden', 90, 'suddenoffset'}

Actors:SetDrawByZPosition(true)

func {4, function()
	LeftPersonBox:hidden(0):zoom2(0);
end}
do
	local anims = {
		{3, 6, 'LeftPersonBox:zoom2'},
		{7, 10, 'RightPersonBox:zoom2'},
		{11, 14, 'LeftPersonBox:zoom2'},
		{19, 22, 'LeftPersonBox:zoom2'},
		{23, 26, 'RightPersonBox:zoom2'}
	}

	for _, v in ipairs(anims) do
		local startBeat = v[1]
		local endBeat = v[2]
		local target = v[3]

		func_ease {startBeat, 2, inOutExpo, 0, 1, target}
		func_ease {endBeat, 2, inExpo, 1, 0, target}
	end

	func_ease {14, 2, inExpo, 0, 1, 'RightPersonBox:zoom2'}
	func_ease {18, 2, inExpo, 1, 0, 'RightPersonBox:zoom2'}
	func_ease {27, 2, inOutExpo, 0, 1, 'LeftPersonBox:zoom2'}
	func_ease {31, 2, inOutQuad, 1, 0, 'LeftPersonBox:diffusealpha'}
	func_ease {31, 2, inOutQuad, 0, 1, 'BothTalkBox:diffusealpha'}

	local faceLeft = {
		{4, LeftPerson, LeftPersonTalk:GetTexture()},

		{8, LeftPerson, LPersonTalk:GetTexture()},
		{8, RightPerson, RightPersonTalk:GetTexture()},

		{9, LeftPerson, LeftPersonHappy:GetTexture()},

		{12, RightPerson, RPersonTalk:GetTexture()},
		{12, LeftPerson, LeftPersonTalk:GetTexture()},

		{16, RightPerson, RightPersonTalk:GetTexture()},
		{16, LeftPerson, LeftPersonHappy:GetTexture()},

		{20, RightPerson, RPersonTalk:GetTexture()},
		{20, LeftPerson, LPersonTalk:GetTexture()},
		
		{21, LeftPerson, LeftPersonTalk:GetTexture()},

		{24, LeftPerson, LPersonTalk:GetTexture()},
		{24, RightPerson, RightPersonTalk:GetTexture()},
		
		{25, LeftPerson, LeftPersonHappy:GetTexture()},

		{28, LeftPerson, LeftPersonTalk:GetTexture()},
		{28, RightPerson, RPersonTalk:GetTexture()},

		{32, LeftPerson, LeftPersonHappy:GetTexture()},
		{32, RightPerson, RightPersonTalk:GetTexture()}
	};
	for _,v in ipairs(faceLeft) do
		local beat = v[1]
		local target = v[2]
		local rageTexture = v[3]

		func {beat, function()
			target:SetTexture(rageTexture)
		end}
	end
end

if not twoPlayers then
	local function playerZoom(p)
		for pn = 1, 2 do
			P[pn]:zoom2(p)
		end
	end

	func {0, function()
		P3:zoom(.5):y(100):addx(50):zoom2(0)
		for pn = 1, 2 do
			P[pn]:zoom(.5):y(100):zoom2(0):addx(-25)
		end
	end}

	local anims = {
		{3, 6, 'P3:zoom2'},
		{7, 10, playerZoom},
		{11, 14, 'P3:zoom2'},
		{19, 22, 'P3:zoom2'},
		{23, 26, playerZoom},
	};
	for _, v in ipairs(anims) do
		local stBeat = v[1];
		local eBeat = v[2];
		local target = v[3];
		func_ease {stBeat, 2, inOutExpo, 0, 1, target}
		func_ease {eBeat, 2, inExpo, 1, 0, target}
	end
	func_ease {14, 2, inExpo, 0, 1, playerZoom}
	func_ease {18, 2, inExpo, 1, 0, playerZoom}
	func_ease {27, 2, inOutExpo, 0, 1, 'P3:zoom2'}
	func_ease {30, 2, inExpo, 0, 1, playerZoom}

	set {19, 100, 'flip', plr=3}
	set {23, 100, 'invert', plr={1,2}} -- :evil:
	set {27, 75, 'flip', 100, 'reverse', -125, 'invert', plr=3}
	set {31, 0, 'invert', plr={1,2}}
	ease {32, 4, inOutQuad, 0, 'reverse', 0, 'flip', 0, 'invert', plr=3}

	node {'dark', function(p) -- why dark only works after 50%?
		return 50 + p;
	end, 'dark'}

	set {0, 30, 'stealth', plr=3, 30, 'dark'}
	set {10, 0, 'stealth', plr=3, 0, 'dark'}

	perframe {19, 32-19, function(b,p)
		for pn = 1, 3 do
			p[pn].movey = -math.abs(math.sin(b * math.pi) * 75);
			if pn <= 2 then
				if b < 21 then
					p[pn].movey = 0;
				end
			end
		end
	end}

	func_ease {32, 4, inOutQuad, scx/2 + 50, scx-100, 'P3:x'}
	func_ease {32, 4, inOutQuad, scx/2+scx - 25, scx+100, function(p)
		for pn = 1, 2 do P[pn]:x(p) end
	end}

	perframe {36, 68-36, function(b,p)
		for pn = 1, 2 do
			local sideChange = inOutExpo(math.clamp((b-50)/4, 0, 1));
			local flipSide = scale(sideChange, 0, 1, 1, -1)
			P[pn]:zoomx2(1 + bounce(sideChange))
			P[pn]:x(scx + math.cos(b * math.pi / 2) * 100 * flipSide);
			P[pn]:z(math.sin(b * math.pi / 2) * 125);
			P[pn]:zoomz(1 + math.abs(math.sin(b * math.pi) * 25))
			p[pn].bumpy = (1 - outExpo(b % 1)) * 100 * math.sin(b * math.pi / 2);
			p[pn].y = -math.abs(math.sin(b * math.pi) * 75);
			p[pn].brake = (1 - outQuad(b % 1)) * 100
		end

		P[3]:x((-(P[1]:GetX() - scx)) + scx)
		P[3]:z(-P[1]:GetZ())
		P[3]:zoomz(P[1]:GetZoomZ())
		P[3]:zoomx2(P[1]:GetZoomX2())
		p[3].bumpy = p[1].bumpy;
		p[3].y = p[1].y;
		
		p[3].rotationz = (b-36) * 90 % 360;
		p[3].confusionoffset = -p[3].rotationz;
		p[3].brake = p[1].brake;
	end}

	ease {34, 4, inOutExpo, -50, 'skewx', 40, 'noteskewx', 150, 'cubicx', plr=3}
	ease {34, 4, inOutExpo, 50, 'skewx', -40, 'noteskewx', -150, 'cubicx', plr={1,2}}

	local mult = 1;
	for i = 38, 66, 4 do
		if i < 50 then
			ease {i, 4, inOutExpo, 50 * mult, 'skewx', -40 * mult, 'noteskewx', -150 * mult, "cubicx", plr=3}
			ease {i, 4, inOutExpo, -50 * mult, 'skewx', 40 * mult, 'noteskewx', 150 * mult, 'cubicx', plr={1,2}}
		else
			ease {i, 4, inOutExpo, 50 * mult, 'skewx', -40 * mult, 'noteskewx', 150 * mult, "cubicx", plr={1,2}}
			ease {i, 4, inOutExpo, -50 * mult, 'skewx', 40 * mult, 'noteskewx', -150 * mult, 'cubicx', plr=3}
		end
		mult = mult * -1;
	end

	set {32, 100, 'scrollspeedmult', plr=3}
	ease {32, 4, inOutQuad, 75, 'scrollspeedmult', plr=3}
else
	func {0, function()
		P1:zoom(.5):y(100):addx(50):zoom2(0)
		P2:zoom(.5):y(100):zoom2(0):addx(-25)
	end}

	local anims = {
		{3, 6, 'P1:zoom2'},
		{7, 10, 'P2:zoom2'},
		{11, 14, 'P1:zoom2'},
		{19, 22, 'P1:zoom2'},
		{23, 26, 'P2:zoom2'},
	};
	for _, v in ipairs(anims) do
		local stBeat = v[1];
		local eBeat = v[2];
		local target = v[3];
		func_ease {stBeat, 2, inOutExpo, 0, 1, target}
		func_ease {eBeat, 2, inExpo, 1, 0, target}
	end
	func_ease {14, 2, inExpo, 0, 1, 'P2:zoom2'}
	func_ease {18, 2, inExpo, 1, 0, 'P2:zoom2'}
	func_ease {27, 2, inOutExpo, 0, 1, 'P1:zoom2'}
	func_ease {30, 2, inExpo, 0, 1, 'P2:zoom2'}

	set {19, 100, 'flip', plr=1}
	set {23, 100, 'invert', plr=2} -- :evil:
	set {27, 75, 'flip', 100, 'reverse', -125, 'invert', plr=1}
	set {31, 0, 'invert', plr=2}
	ease {32, 4, inOutQuad, 0, 'reverse', 0, 'flip', 0, 'invert', plr=1}

	perframe {19, 32-19, function(b,p)
		for pn = 1, 2 do
			p[pn].movey = -math.abs(math.sin(b * math.pi) * 75);
			if pn == 2 then
				if b < 21 then
					p[pn].movey = 0;
				end
			end
		end
	end}

	func_ease {32, 4, inOutQuad, scx/2 + 50, scx-100, 'P1:x'}
	func_ease {32, 4, inOutQuad, scx/2+scx - 25, scx+100, 'P2:x'}

	perframe {36, 68-36, function(b,p)
		local sideChange = inOutExpo(math.clamp((b-50)/4, 0, 1));
		local flipSide = scale(sideChange, 0, 1, 1, -1)
		P[2]:zoomx2(1 + bounce(sideChange))
		P[2]:x(scx + math.cos(b * math.pi / 2) * 100 * flipSide);
		P[2]:z(math.sin(b * math.pi / 2) * 125);
		P[2]:zoomz(1 + math.abs(math.sin(b * math.pi) * 25))
		p[2].bumpy = (1 - outExpo(b % 1)) * 100 * math.sin(b * math.pi / 2);
		p[2].y = -math.abs(math.sin(b * math.pi) * 75);

		P[1]:x((-(P[2]:GetX() - scx)) + scx)
		P[1]:z(-P[2]:GetZ())
		P[1]:zoomz(P[2]:GetZoomZ())
		P[1]:zoomx2(P[2]:GetZoomX2())
		p[1].bumpy = p[2].bumpy;
		p[1].y = p[2].y;
		
		for pn = 1, 2 do
			p[pn].brake = (1 - outQuad(b % 1)) * 100
		end
	end}

	ease {34, 4, inOutExpo, -50, 'skewx', 40, 'noteskewx', 150, 'cubicx', plr=2}
	ease {34, 4, inOutExpo, 50, 'skewx', -40, 'noteskewx', -150, 'cubicx', plr=1}

	local mult = 1;
	for i = 38, 66, 4 do
		if i < 50 then
			ease {i, 4, inOutExpo, 50 * mult, 'skewx', -40 * mult, 'noteskewx', -150 * mult, "cubicx", plr=2}
			ease {i, 4, inOutExpo, -50 * mult, 'skewx', 40 * mult, 'noteskewx', 150 * mult, 'cubicx', plr=1}
		else
			ease {i, 4, inOutExpo, 50 * mult, 'skewx', -40 * mult, 'noteskewx', 150 * mult, "cubicx", plr=1}
			ease {i, 4, inOutExpo, -50 * mult, 'skewx', 40 * mult, 'noteskewx', -150 * mult, 'cubicx', plr=2}
		end
		mult = mult * -1;
	end

	set {32, 100, 'scrollspeedmult', plr=1}
	ease {32, 4, inOutQuad, 75, 'scrollspeedmult', plr=1}
end

func {68, 'Camera:diffuse', 0, 0, 0, 0}
perframe {36, 68-36, function(b,p)
	local intro = outQuad(math.clamp((b-35) / 4, 0, 1));
	p[1].czoom = (1 - outQuad(math.clamp((b % 1) * 2, 0, 1))) * 0.03125 * intro
	Camera:rotationz(math.sin(b * math.pi / 4) * 2 * intro)
end}
ease {50, 4, inOutExpo, 100, 'reverse'}
func_ease {36, 4, inOutQuad, 0, 0.15, 'RainbowSpr:diffusealpha'}

ease {36, 2, inOutQuad, 50, 'tipsy'}
set {36, 100, 'orient'}

ease {35, 1, inQuad, -100, 'tinyx', 100, 'tinyy', 50, 'movey'}
for i = 36, 68 do
	ease {i, .5, outQuad, 25, 'tinyx', -75, 'tinyy', 0, 'movey'}
	ease {i+.5, .5, inQuad, -150, 'tinyx', 125, 'tinyy', 50, 'movey'}

	if i % 2 == 1 then
		if not twoPlayers then
			ease {i, 2, flip(outExpo), 10, 'confusion'}
		else
			ease {i, 2, flip(outExpo), 10, 'confusion', plr=2}
		end
	end

	ease {i, 2, flip(outExpo), 0.25, 'bloom'}
end