// from https://www.shadertoy.com/view/lsXGWn
#version 120

uniform sampler2D sampler0;
uniform vec2 textureSize;
uniform vec2 imageSize;
varying vec2 textureCoord;
varying vec2 imageCoord;
varying vec4 color;
uniform float time;

uniform float strength;

void main() {
  float blurSize = 1.0/256.0;

  vec4 sum = vec4(0);
  vec2 texcoord = textureCoord;

  //thank you! http://www.gamerendering.com/2008/10/11/gaussian-blur-filter-shader/ for the 
  //blur tutorial
  // blur in y (vertical)
  // take nine samples, with the distance blurSize between them
  sum += texture2D(sampler0, vec2(texcoord.x - 4.0*blurSize, texcoord.y)) * 0.05;
  sum += texture2D(sampler0, vec2(texcoord.x - 3.0*blurSize, texcoord.y)) * 0.09;
  sum += texture2D(sampler0, vec2(texcoord.x - 2.0*blurSize, texcoord.y)) * 0.12;
  sum += texture2D(sampler0, vec2(texcoord.x - blurSize, texcoord.y)) * 0.15;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y)) * 0.16;
  sum += texture2D(sampler0, vec2(texcoord.x + blurSize, texcoord.y)) * 0.15;
  sum += texture2D(sampler0, vec2(texcoord.x + 2.0*blurSize, texcoord.y)) * 0.12;
  sum += texture2D(sampler0, vec2(texcoord.x + 3.0*blurSize, texcoord.y)) * 0.09;
  sum += texture2D(sampler0, vec2(texcoord.x + 4.0*blurSize, texcoord.y)) * 0.05;

// blur in y (vertical)
  // take nine samples, with the distance blurSize between them
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y - 4.0*blurSize)) * 0.05;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y - 3.0*blurSize)) * 0.09;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y - 2.0*blurSize)) * 0.12;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y - blurSize)) * 0.15;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y)) * 0.16;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y + blurSize)) * 0.15;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y + 2.0*blurSize)) * 0.12;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y + 3.0*blurSize)) * 0.09;
  sum += texture2D(sampler0, vec2(texcoord.x, texcoord.y + 4.0*blurSize)) * 0.05;

  gl_FragColor = sum*strength + texture2D(sampler0, texcoord); 
}