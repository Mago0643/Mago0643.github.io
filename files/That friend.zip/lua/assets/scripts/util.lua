---@diagnostic disable: unused-local, lowercase-global, undefined-global, param-type-mismatch
xero()

---@class Difficulty
Difficulty = {}
Difficulty.DIFFICULTY_BEGINNER = 0
Difficulty.DIFFICULTY_EASY = 1
Difficulty.DIFFICULTY_MEDIUM = 2
Difficulty.DIFFICULTY_HARD = 3
Difficulty.DIFFICULTY_CHALLENGE = 4
Difficulty.DIFFICULTY_EDIT = 5

---@class NoteData
NoteData = {}
NoteData.Beat = 0
NoteData.Lane = 1
NoteData.NoteType = 2

theme_actors = {};
local theme_actors_name = {
	'Overlay',
	'Underlay',
	'ScoreP1',
	'ScoreP2',
	'LifeP1',
	'LifeP2',
};
for _,v in ipairs(theme_actors_name) do
  local a = SCREENMAN(v);
  if a then
    table.insert(theme_actors, a)
  end
end

-- the name tells you all.
curDifficulty = GAMESTATE:GetCurrentSteps(0):GetDifficulty()
slumpage = curDifficulty == Difficulty.DIFFICULTY_EDIT
beat_1 = {0, 1.5, 3, 4.5, 6, 7}
-- original player position.
PPOS = {}

--- Uses normal time system for some mods like drunk, tipsy.
GLOBALMODTIMER_NORMAL = 0
--- Makes some mods like drunk, tipsy mods uses song based time.
GLOBALMODTIMER_SONGTIME = 100
--- Makes some mods like drunk, tipsy mods uses beat based time.
GLOBALMODTIMER_SONGBEAT = 200
--- Player's Global Song Offset. (in seconds)
GLOBAL_OFFSET = PREFSMAN:GetPreference("GlobalOffsetSeconds");

---cool text typer
---
---you can make callback for each text typing (for example, typing sounds)
---@param beat number
---@param bitmaptext BitmapText
---@param type_per_beat number
---@param text string
---@param callback function
function typeText(beat, bitmaptext, type_per_beat, text, callback)
  local totalLen = string.len(text);
  for i = 1, totalLen do
    local offset = type_per_beat * i;
    local text = string.sub(text, i, i)
    func {offset+beat, function()
      bitmaptext:settext(bitmaptext:GetText()..text)
      if callback then callback() end
    end}
  end
end

function initMods(moveWindows)
  if moveWindows then
    local dx, dy, dw, dh = DISPLAY_CENTER_X, DISPLAY_CENTER_Y+12, DISPLAY:GetWindowWidth(), DISPLAY:GetWindowHeight();
    definemod {"wx", "wy", "ww", "wh", function(x,y,w,h)
      --doing reset if the values are not correct.
      if x >= 0 and x <= DISPLAY_WIDTH-dw then x = dx end
      if y >= 0 and y <= DISPLAY_HEIGHT-dh then y = dy end
      if w <= 0 then w = dw end
      if h <= 0 then h = dh end
      DISPLAY:SetWindowX(x);
      DISPLAY:SetWindowY(y);
      DISPLAY:SetWindowWidth(w);
      DISPLAY:SetWindowHeight(h);
    end}
  end

  setupAFT(CameraAFT, Camera)

  -- fuckers
  node {
    'confusionxoffset', 'confusionyoffset', 'confusionoffset',
    function(x,y,z)
      return math.rad(x) * 100, math.rad(y) * 100, math.rad(z) * 100
    end,
    'confusionxoffset', 'confusionyoffset', 'confusionoffset'
  }
  -- do the columns too
  for i = 0, 3 do
    node {
      'confusionxoffset'..i, 'confusionyoffset'..i, 'confusionoffset'..i,
      function(x,y,z)
        return math.rad(x) * 100, math.rad(y) * 100, math.rad(z) * 100
      end,
      'confusionxoffset'..i, 'confusionyoffset'..i, 'confusionoffset'..i
    }
  end

  definemod {'czoom', function(a)
    Camera:zoom(a+1)
  end}

  for pn = 1, 2 do
    PPOS[pn] = {P[pn]:GetX(), P[pn]:GetY()};
  end
end

--- bounds value by min - max.
function math.clamp(value, min, max)
	return math.min(math.max(value, min), max)
end


function math.lerp(a,b,t)
  return a + (b - a) * t;
end

-- remaps the value to range.
--
-- useful for converting time to pixels maybe?
function math.remapToRange(value, start1, stop1, start2, stop2)
	return start2 + (stop2 - start2) * (value - start)
end

---@param beat number The Beat Mod should run at.
---@param length number The Length Mod should reset at.
---@param step number How long Loop should go.
---@param speedmod number Current Player's speed mod.
---@param plr nil|integer Player Number.
function drivendrop(beat, length, step, speedmod, plr)
  for i = beat, beat + length - step, step do
    add
    {i, step, linear, speedmod * step * 100, 'centered2', plr = plr}
    {i + step, 0, instant, -speedmod * step * 100, 'centered2', plr = plr}
  end
end

---Automatically inits the AFT, Sprite.
---@param AFT ActorFrameTexture
---@param Sprite Sprite
function setupAFT(AFT, Sprite)
  setupAftSprite(AFT, Sprite)
end

proxyWallX, proxyWallY, wallRender = 0, 0, 0;
---Set Draw Function to the proxy wall, and define some mods.
---
---you can use `prw_x`, `prw_y`, `prw_render`.
---
---`prw_x` moves proxy wall by x axis.
---
---`prw_y` moves proxy wall by y axis.
---
---`prw_render` adjusts how many proxy walls should render.
---@param proxyWalls ActorFrame
function setupProxyWalls(proxyWalls)
  definemod {'prw_x', function(p) proxyWallX = p end}
  definemod {'prw_y', function(p) proxyWallY = p end}
  definemod {'prw_render', function(p) wallRender = p end}
  proxyWalls:SetDrawFunction(function()
    for pn = 1, #PP do
      local half = wallRender / 2;
      for i = -half, half do
        PP[pn]:xy(proxyWallX * i, proxyWallY * i);
        PP[pn]:Draw()
      end
    end
  end)
end

---Loads an .lua file.
function loadscript(name)
  return loadfile(xero.dir..'lua/'..name)()
end

--- **(MUST BE APPLIED WITH "50% flip, 50% reverse"**
function ApplyDPad(beat)
  func {beat, function ()
    for pn = 1, 2 do
      P[pn]:SetXSpline(1, 0, -500, 500, -1)
      P[pn]:SetYSpline(1, 0, -500, -500, -1)
  
      P[pn]:SetYSpline(1, 1, 500, 500, -1)
      P[pn]:SetYSpline(1, 2, -500, 500, -1)
  
      P[pn]:SetXSpline(1, 3, 500, 500, -1)
      P[pn]:SetYSpline(1, 3, -500, -500, -1)
    end
  end}
end

--- flick {beat, len, ease_fn, start_mod_percent, end_mod_percent, mod_name, start_mod_percent, end_mod_percent, mod_name, ...}
--- 
--- sets an mod instantly and ease it
--- 
--- @deprecated JUST USE flip(ease) ON EASE FUNCTION
function flick(self)
	local setTable = {self[1], plr=self.plr}
	local easeTable = {self[1], self[2], self[3], plr=self.plr}

	for i = 4, #self do
		if (i-4)%3 == 0 then
			table.insert(setTable, self[i])
			table.insert(easeTable, self[i+1])
			table.insert(setTable, self[i+2])
			table.insert(easeTable, self[i+2])
		end
	end

	set(setTable)
	ease(easeTable)
end

-- stolen from kaypooma's file
--
-- note stops for each beat.
function noteStop(beat, len, xmod, step)
  if step == nil then step = 1 end
  if xmod == nil then xmod = 1 end
  perframe {beat, len, function(b,p)
    for pn = 1, 2 do
      P[pn]:SetYSpline(1, -1, b>(len+beat-1) and 0 or (b*xmod)%step * 100, 1, -1)
    end
  end}
end

--- damn, i love column swaps.
function getRandomColumnSwap(_lastColumn)
  local tab = {}
  local rnd = math.random(0,6)
  local loop = 0
  -- prevent same value as before
  while _lastColumn == rnd and loop < 1000 do
    rnd = math.random(0,6)
    loop = loop + 1
  end
  if loop >= 1000 then
    warn("loop reached over 1,000")
  end
  if rnd == 0 then
    tab = {100, 'flip', 0, 'invert'}
  elseif rnd == 1 then
    tab = {0, 'flip', 100, 'invert'}
  elseif rnd == 2 then
    tab = {25, 'flip', -75, 'invert'}
  elseif rnd == 3 then
    tab = {75, 'flip', 75, 'invert'}
  elseif rnd == 4 then
    tab = {100, 'flip', -100, 'invert'}
  elseif rnd == 5 then
    tab = {75, 'flip', -125, 'invert'}
  elseif rnd == 6 then
    tab = {25, 'flip', 125, 'invert'}
  end
  return tab, rnd
end