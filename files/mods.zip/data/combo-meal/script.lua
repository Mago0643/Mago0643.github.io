function onCreate()
    --addLuaScript('SimpleModchartTemplate') -- load the script
    --triggerEvent('legacyPsychMode') 


end

--MODCHART SETTINGS
local intro = true; -- stupid "Skip Time" bug stuff
local slumpage = false; -- change this to 'true' if you want to try hard mode.

local FNF_SCROLL_SPEED_MUL = .45; -- idk fnf uses this or somethin
local scrollSwitch = 520 --can be useful for when changing y values to work with both scrolls
--example, want to move note y to center of the screen, use the value scrollSwitch/2 and it should work both upscroll and downscroll 

function onCreatePost()
    if downscroll then 
		scrollSwitch = -520
	end

    --setProperty('incomingAngle.x', 90)

    --setProperty('playerNotePathAlpha.alpha', 0.75)
    if getPropertyFromClass('ClientPrefs', 'modcharts') then 
        runHaxeCode([[
            game.playfieldRenderer = new PlayfieldRenderer(game.strumLineNotes, game.notes, game);
            game.playfieldRenderer.cameras = [game.camHUD];
            game.add(game.playfieldRenderer);
            game.remove(game.grpNoteSplashes);
            game.add(game.grpNoteSplashes);
        ]])

        removeLuaSprite('theLimit', false)
        removeLuaText('limitCounter', false)
        addLuaSprite('theLimit',true);
        addLuaText('limitCounter');

        -- if you wonder why i'm good at making modcharts. cuz i made modcharts in NotITG since 2018
		startMod("beat", "BeatXModifier");
		startMod("drunk", "DrunkXModifier");
		startMod("tipsy", "TipsyYModifier");
		startMod("rotation", "RotateModifier");
		startMod("jojo", "Modifier");
		startMod("zbuffer", "Modifier");
		startMod("bumpy", "BumpyModifier");
		startMod("drunkz", "Modifier");
		for col = 0, 7 do
			startMod("reverse"..col, "ReverseModifier", "Lane");
			setModTargetLane("reverse"..col, col);
		end
		startMod("reverse", "ReverseModifier");
		startMod("final", "Modifier");
		startMod("dark", "Modifier");
        startMod("digital", "Modifier");

        if slumpage then -- colum swap :evil:
            startMod("invert", "InvertModifier"); -- down left right up
            startMod("flip", "FlipModifier"); -- right up down left
            startMod("ilovevideogames", "Modifier"); -- left right up down
            startMod("wtf", "Modifier"); -- the strum circler thing
        end
		
		runHaxeCode([[
			var FNF_SCROLL_SPEED_MUL = ]]..FNF_SCROLL_SPEED_MUL..[[;
            var SLUMPAGE = ]]..tostring(slumpage)..[[;
			var ohno = game.playfieldRenderer.modifiers.get("jojo");
			ohno.noteMath = function(noteData, lane, curPos, pf) {
				var note = game.notes.members[noteData.index];
				var a = ohno.currentValue;
                game.strumLineNotes.members[lane].colorSwap.saturation = -0.95*a;
                game.strumLineNotes.members[lane].colorSwap.brightness = -0.2*a;
                
                // shut up bunz, i kill you.
                if (SLUMPAGE)
                {
                    note.colorSwap.saturation = -0.95*a;
                    note.colorSwap.brightness = -0.2*a;
                    note.noteSplashBrt = -0.2*a;
                    note.noteSplashSat = -0.95*a;
                } else {
                    if (note.noteType != "Sauce Note")
                    {
                        note.colorSwap.saturation = -0.95*a;
                        note.colorSwap.brightness = -0.2*a;
                        note.noteSplashBrt = -0.2*a;
                        note.noteSplashSat = -0.95*a;
                    } else {
                        if (note.mustPress) {
                            note.colorSwap.brightness = -100*a;
                            note.noteSplashBrt = -100*a;
                        } else {
                            note.colorSwap.saturation = -0.95*a;
                            note.colorSwap.brightness = -0.2*a;
                            note.noteSplashBrt = -0.2*a;
                            note.noteSplashSat = -0.95*a;
                        }
                    }
                }
            }
			
			var dz = game.playfieldRenderer.modifiers.get("drunkz");
			dz.noteMath = function(noteData, lane, curPos, pf) {
				var speed = 7.5;
				var swagWidth = 160 * 0.7;
				noteData.z += dz.currentValue * (Math.tan( ((Conductor.songPosition*0.001) + ((lane%4)*0.2) + (curPos*0.45)*0.25*(10/720)) * (speed*0.2)) * swagWidth*0.5);
			}
			
			dz.strumMath = function(noteData, lane, pf) {
				dz.noteMath(noteData, lane, 0, pf);
			}
			
			var zBuffer = game.playfieldRenderer.modifiers.get("zbuffer");
			zBuffer.noteMath = function(noteData, lane, curPos, pf) {
				var a = zBuffer.currentValue;
				noteData.z += curPos%1000*a;
			}
			
			var fin = game.playfieldRenderer.modifiers.get("final");
			fin.noteMath = function(noteData, lane, curPos, pf) {
                if (lane >= 4 && lane <= 7) {
                    var v = fin.currentValue;
                    noteData.z += (curPos*3)*v;
                    noteData.y += ((Math.sin(-curPos*0.001)*400)*v);
                    noteData.x += (100 - Math.cos(curPos*0.001)*100)*v;
                }
			}
			
			var dark = game.playfieldRenderer.modifiers.get("dark");
			dark.strumMath = function(noteData, lane, pf) {
				noteData.alpha = 1.0 - dark.currentValue;
			}

            var ok = game.playfieldRenderer.modifiers.get("ilovevideogames");
            if (ok != null) {
               ok.noteMath = function(noteData, lane, curPos, pf) {
                    switch (lane % 4) {
                        case 0|1:
                            noteData.x += (125*2)*ok.currentValue;
                        case 2|3:
                            noteData.x -= (125*2)*ok.currentValue;
                    }
                }

                ok.strumMath = function(noteData, lane, pf) {
                    ok.noteMath(noteData, lane, 0, pf);
                }
            }

            var ok2 = game.playfieldRenderer.modifiers.get("wtf");
            if (ok2 != null) {
                ok2.strumMath = function(noteData, lane, pf) {
                    var v = ok2.currentValue;
                    noteData.x += (50 - Math.cos(Conductor.songPosition / 1000 + (lane%4)) * 50) * v;
                    noteData.y += (50 - Math.sin(Conductor.songPosition / 1000 + (lane%4)) * 50) * v;
                }

                ok2.noteMath = function(noteData, lane, curPos, pf) {
                    ok2.strumMath(noteData, lane, pf);
                }
            }

            var fuck = game.playfieldRenderer.modifiers.get("digital");
            fuck.noteMath = function(noteData, lane, curPos, pf) {
                // you can see this at https://github.com/stepmania/stepmania/blob/984dc8668f1fedacf553f279a828acdebffc5625/src/ArrowEffects.cpp#L189C13-L189C13
                var ARROW_SIZE = 112;
                var steps = 0;
                var period = (SLUMPAGE ? 0 : 0.5);
                var offset = 0;
                noteData.x+=(fuck.currentValue*ARROW_SIZE*0.5)*Math.round((steps+1)*Math.sin(Math.PI*(curPos+(1*offset))/(ARROW_SIZE+(period*ARROW_SIZE))))/(steps+1);
                noteData.y+=(fuck.currentValue*ARROW_SIZE*0.5)*Math.round((steps+1)*Math.cos(Math.PI*(curPos+(1*offset))/(ARROW_SIZE+(period*ARROW_SIZE))))/(steps+1);
            }
		]]);
		
		set (0, "5, drunk:speed, 5, tipsy:speed, 1, rotation, 2, bumpy:speed");
		
        if intro then
            for i = 0, 32, 16 do
                local ease_str = "quad";
                ease (i, 1, ease_str.."Out", "975, x0, -975, x7")
                ease (i, 0.5, ease_str.."Out", "-200, y0, 200, y7");
                ease (i+.5, 0.5, ease_str.."In", "0, y0, 0, y7")
                ease (i+1.5, 1, ease_str.."Out", "750, x1, -750, x6")
                ease (i+1.5, 0.5, ease_str.."Out", "175, y1, -175, y6");
                ease (i+2, 0.5, ease_str.."In", "0, y1, 0, y6");
                
                ease (i+4, 1, ease_str.."Out", "525, x2, -525, x5");
                ease (i+4, 0.5, ease_str.."Out", "-150, y2, 150, y5");
                ease (i+4.5, 0.5, ease_str.."In", "0, y2, 0, y5");
                ease (i+5.5, 1, ease_str.."Out", "300, x3, -300, x4");
                ease (i+5.5, 0.5, ease_str.."Out", "125, y3, -125, y4");
                ease (i+6, 0.5, ease_str.."In", "0, y3, 0, y4");
                
                ease (i+8, 1, ease_str.."Out", "0, x3, 0, x4");
                ease (i+8, 0.5, ease_str.."Out", "125, y3, -125, y4");
                ease (i+8.5, 0.5, ease_str.."In", "0, y3, 0, y4");
                ease (i+9.5, 1, ease_str.."Out", "0, x2, 0, x5");
                ease (i+9.5, 0.5, ease_str.."Out", "-150, y2, 150, y5");
                ease (i+10, 0.5, ease_str.."In", "0, y2, 0, y5");
                
                ease (i+12, 1, ease_str.."Out", "0, x1, 0, x6");
                ease (i+12, 0.5, ease_str.."Out", "175, y1, -175, y6");
                ease (i+12.5, 0.5, ease_str.."In", "0, y1, 0, y6");
                ease (i+13.5, 1, ease_str.."Out", "0, x0, 0, x7");
                ease (i+13.5, 0.5, ease_str.."Out", "-200, y0, 200, y7");
                ease (i+14, 0.5, ease_str.."In", "0, y0, 0, y7");
            end
        end
		
		local function cockeandballs(i)
            if slumpage then
                set (i, "4, drunk")
                ease (i, 0.5, "expoIn", "100, drunk")
                set (i+0.5, "-4, drunk")
                ease (i+0.5, 3.5, "expoOut", "0, drunk")
            else
                set (i, "-4, drunk")
			    ease (i, 4, "expoOut", "0, drunk");
            end
			
			set (i+1, "-2, tipsy");
			ease (i+1, 0.5, "expoOut", "0, tipsy");
			set (i+1.5, "2, tipsy");
			ease (i+1.5, 0.5, "expoOut", "0, tipsy");
			
			set (i+2, "-2, drunk");
			ease (i+2, 1, "expoOut", "0, drunk");
			set (i+3, "2, drunk");
			ease (i+3, 1, "expoOut", "0, drunk");
            if slumpage and i+2 >= 48 then
                ease (i+2, 1, "expoOut", "1, flip");
                ease (i+3, 1, "expoOut", "0, flip");
            end
			
			if slumpage then
                set (i+4, "-4, drunk")
                ease (i+4, 0.5, "expoIn", "100, drunk")
                set (i+4.5, "4, drunk")
                ease (i+4.5, 3.5, "expoOut", "0, drunk")
            else
                set (i+4, "2, drunk")
			    ease (i+4, 4, "expoOut", "0, drunk");
            end
			
			set (i+5, "-2, tipsy");
			ease (i+5, 0.5, "expoOut", "0, tipsy");
			set (i+5.5, "2, tipsy");
			ease (i+5.5, 0.5, "expoOut", "0, tipsy");
			
			set (i+6, "-2, drunk");
			ease (i+6, 1, "expoOut", "0, drunk");
			set (i+7, "2, drunk");
			ease (i+7, 1, "expoOut", "0, drunk");
            if slumpage and i+6 >= 48 then
                ease (i+6, 1, "expoOut", "1, invert");
                ease (i+7, 1, "expoOut", "0, invert");
            end
			
			set (i+8, "-2, drunk");
			ease (i+8, 1, "expoOut", "0, drunk");
			set (i+9, "2, drunk");
			ease (i+9, 1, "expoOut", "0, drunk");
			
			set (i+10, "-2, tipsy");
			ease (i+10, 0.5, "expoOut", "0, tipsy");
			set (i+10.5, "-2, tipsy");
			ease (i+10.5, 0.5, "expoOut", "0, tipsy");		
			set (i+11, "2, tipsy");
			ease (i+11, 0.5, "expoOut", "0, tipsy");
			set (i+11.5, "2, tipsy");
			ease (i+11.5, 0.5, "expoOut", "0, tipsy");
			
			ease (i+12, 1, "expoOut", "1, reverse0, 1, reverse7");
			ease (i+12.5, 1, "expoOut", "1, reverse1, 1, reverse6");
			ease (i+13, 1, "expoOut", "1, reverse2, 1, reverse5");
			ease (i+13.5, 1, "expoOut", "1, reverse3, 1, reverse4");
            if slumpage and i+12 >= 48 then
                ease (i+12, 2, "expoOut", "1, ilovevideogames");
                ease (i+14, 2, "expoOut", "0, ilovevideogames");
            end
			
			ease (i+14, 1, "expoOut", "0, reverse0, 0, reverse7");
			ease (i+14.5, 1, "expoOut", "0, reverse1, 0, reverse6");
			ease (i+15, 1, "expoOut", "0, reverse2, 0, reverse5");
			ease (i+15.5, 1, "expoOut", "0, reverse3, 0, reverse4");
		end
		
		for i = 16, 32*5, 16 do
			cockeandballs(i);
		end
		
		for i = 240, 448, 16 do
			cockeandballs(i);
		end
		
		for i = 528, 576, 16 do
			cockeandballs(i);
		end
		
		set (48, "360, rotation:y, 1, beat, 360, rotation:x")
		ease (48, 4, "elasticOut", "0, rotation:y, 0, rotation:x");
		
		for i = 208, 236, 8 do
			ease (i, 2, "expoInOut", "1, reverse");
			ease (i+4, 2, "expoInOut", "0, reverse");
		end
		
		set (240, "360, rotation:y, 360, rotation:x")
		ease (240, 4, "elasticOut", "0, rotation:y, 0, rotation:x");
		
		set (304, "0, jojo, 3, bumpy");
		ease (364, 4, "linear", "0, bumpy, 1, drunkz");
		
		set (400, "360, rotation:y, 360, rotation:x")
		ease (400, 4, "elasticOut", "0, rotation:y, 0, drunkz, 0, rotation:x");
		ease (460, 4, "expoIn", "-350, x, 0.5, reverse, -200, x3, -200, x2, 1, final");
		if not slumpage then
			ease (460, 4, "expoIn", "0.75, dark");
		end
		
		set (464, "360, rotation:y, , 360, rotation:x")
		ease (464, 4, "elasticOut", "0, rotation:y, 0, rotation:x");
		
		set (176, "360, rotation:y, 0, beat, 1, jojo, 1, zbuffer, 360, rotation:x, 0.5, digital")
		ease (176, 4, "elasticOut", "0, rotation:y, 0, rotation:x");
		ease (236, 4, "quadIn", "0, zbuffer, 0, digital");

        ease (528, 4, "expoOut", "0, final, 0, x2, 0, x3, 0, reverse, 0, x, 0, dark");
		
		set (240, "2, beat");
		set (368, "0, beat");
		set (400, "2, beat");
		set (464, "5. beat");
		set (528, "0, beat");
		set (560, "2, beat");
		set (588, "0, beat");

        if slumpage then
            set (176, "1, wtf");
            ease (240, 2, "expoOut", "0, wtf");
        end
    end
end

-- putting this on custom mod it lags so much
function onSpawnNote(id, data, type, isSustainNote, strumTime)
    if strumTime >= 54153 and strumTime < 93538 then
        if not slumpage then
            runHaxeCode([[
                var note = game.notes.members[]]..id..[[];
                if (note.noteType != "Sauce Note")
                {
                    note.colorSwap.saturation = -0.95;
                    note.colorSwap.brightness = -0.2;
                    note.noteSplashBrt = -0.2;
                    note.noteSplashSat = -0.95;
                } else {
                    if (note.mustPress) {
                        note.colorSwap.brightness = -100;
                        note.noteSplashBrt = -100;
                    } else {
                        note.colorSwap.saturation = -0.95;
                        note.colorSwap.brightness = -0.2;
                        note.noteSplashBrt = -0.2;
                        note.noteSplashSat = -0.95;
                    }
                }
            ]])
        else
            runHaxeCode([[
                var note = game.notes.members[]]..id..[[];
                note.colorSwap.saturation = -0.95;
                note.colorSwap.brightness = -0.2;
                note.noteSplashBrt = -0.2;
                note.noteSplashSat = -0.95;
            ]])
        end
    end
end

function onSongStart()--for step 0
    --introBuzz()
    --triggerEvent('setTimeStop', '54180', '93500')

   
end

local mainMelody = {0, 4,6,8,12, 16, 20, 22, 24, 28, 32, 36, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62}
local longNotes = {0,8,12,16,24,28,32,40}

local woap = {192,704, 960, 1216, 1600, 1856}

local startMoveThing = 0
local waveThing = 0

local sectionsToNotDoMelodyThing = {0,1,2,3,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,58,59,92,93,94,95,96,97,98,99,132,133,134,135,136,137,138,139,147,148,149,150}
local swapThing = 1

function onStepHit()
    --[[
    local doMelodyThing = true
    for i = 0,#sectionsToNotDoMelodyThing-1 do 
        if math.floor(curStep/16) == sectionsToNotDoMelodyThing[i+1] then 
            doMelodyThing = false
        end
    end
    if doMelodyThing then 
        for i = 0,#mainMelody-1 do --reads a list of steps from the array
            if curStep % 64 == mainMelody[i+1] then 
                local played = false
                for j = 0,#longNotes-1 do 
                    if curStep % 64 == longNotes[j+1] then
                        setProperty('tipsy.y', 0.5)
                        doTweenY('tipsy', 'tipsy', 0, stepCrochet/500, 'backInOut')
                        swapThing = swapThing * -1
                        played = true
                    end
                end
    
                if curStep % 64 >= 48 then 
                    setProperty('strumOffset'..waveThing..'.y', -20)
                    setProperty('strumOffset'..(waveThing+4)..'.y', -20)
                    if waveThing == 0 then 
                        setProperty('strumOffset'..(3)..'.y', 0)
                        setProperty('strumOffset'..(7)..'.y', 0)
                    else 
                        setProperty('strumOffset'..(waveThing-1)..'.y', 0)
                        setProperty('strumOffset'..(waveThing-1+4)..'.y', 0)
                    end
                    played = true
                    waveThing = (waveThing + 1) % 4
                end
                if not played then 
                    setProperty('scale.x', 1)
                    doTweenX('scaleX', 'scale', 0.7, stepCrochet/500, 'backInOut')       
                end
                --0triggerEvent('Add Camera Zoom', 0.005, 0.005)
            end
        end
    end
    
    if curStep % 64 == 0 then 
        for j = 0,7 do 
            setProperty('strumOffset'..j..'.y', 0)
        end
    end


    introBuzz()


    if curStep == 192 then 
        for i = 0,7 do 
            doTweenAngle('strumOffset'..i, 'strumOffset'..i, 0, (stepCrochet/1000)*3, 'cubeInOut')
            doTweenAngle('confusion'..i, 'confusion'..i, 0, (stepCrochet/1000)*3, 'cubeInOut')
        end
    elseif curStep == 704 then 
        doTweenAngle('globalStrumOffset', 'globalStrumOffset', -200, (stepCrochet/1000)*3, 'cubeInOut') 
    elseif curStep == 960 then 
        doTweenAngle('globalStrumOffset', 'globalStrumOffset', 0, (stepCrochet/1000)*3, 'cubeInOut') 

    elseif curStep == 832 then 
        doTweenX('speen', 'noteRot', 180, (stepCrochet/1000)*6, 'cubeInOut')
        local time = (stepCrochet/1000)*6
        local ease = 'cubeInOut'
        doTweenX('0x', 'strumOffset0', -112 * 3, time, ease)
        doTweenX('1x', 'strumOffset1', -112 * 1, time, ease)
        doTweenX('2x', 'strumOffset2', -112 * -1, time, ease)
        doTweenX('3x', 'strumOffset3', -112 * -3, time, ease)
        doTweenX('4x', 'strumOffset4', -112 * 3, time, ease)
        doTweenX('5x', 'strumOffset5', -112 * 1, time, ease)
        doTweenX('6x', 'strumOffset6', -112 * -1, time, ease)
        doTweenX('7x', 'strumOffset7', -112 * -3, time, ease) 
        --triggerEvent('flip',''..(stepCrochet/1000)*3, 'cubeInOut')
    elseif curStep == 864 then 
        doTweenX('speen', 'noteRot', 360, (stepCrochet/1000)*6, 'cubeInOut') 
        triggerEvent('resetX',''..(stepCrochet/1000)*6, 'cubeInOut')
    elseif curStep == 832+64 then 
        doTweenX('speen', 'noteRot', 180, (stepCrochet/1000)*6, 'cubeInOut') 
        --triggerEvent('flip',''..(stepCrochet/1000)*3, 'cubeInOut')
        local time = (stepCrochet/1000)*6
        local ease = 'cubeInOut'
        doTweenX('0x', 'strumOffset0', -112 * 3, time, ease)
        doTweenX('1x', 'strumOffset1', -112 * 1, time, ease)
        doTweenX('2x', 'strumOffset2', -112 * -1, time, ease)
        doTweenX('3x', 'strumOffset3', -112 * -3, time, ease)
        doTweenX('4x', 'strumOffset4', -112 * 3, time, ease)
        doTweenX('5x', 'strumOffset5', -112 * 1, time, ease)
        doTweenX('6x', 'strumOffset6', -112 * -1, time, ease)
        doTweenX('7x', 'strumOffset7', -112 * -3, time, ease) 
    elseif curStep == 864+64 then 
        doTweenX('speen', 'noteRot', 0, (stepCrochet/1000)*6, 'cubeInOut') 
        triggerEvent('resetX',''..(stepCrochet/1000)*6, 'cubeInOut')
    elseif curStep == 1840 then 
        if not middlescroll then 
            doTweenX('playerStrumOffset', 'playerStrumOffset', -160, (stepCrochet/1000)*3, 'cubeInOut') 
            doTweenX('opponentStrumOffset', 'opponentStrumOffset', 160, (stepCrochet/1000)*3, 'cubeInOut') 
        else
           
        end

    elseif curStep == 1848 then 
        if not middlescroll then 
            doTweenX('playerStrumOffset', 'playerStrumOffset', -320, (stepCrochet/1000)*3, 'cubeInOut') 
            doTweenX('opponentStrumOffset', 'opponentStrumOffset', 320, (stepCrochet/1000)*3, 'cubeInOut') 
        else 
           
        end

    elseif curStep == 784 then 
        --triggerEvent('setTimeStop', '64050', '68640')
    elseif curStep == 944 then 
        --triggerEvent('setTimeStop', '92370', '92890')
    end

    for i = 0,#woap-1 do --reads a list of steps from the array
        if curStep == woap[i+1] then 

            for j = 0,7 do 
                local ang = 360 
                if j % 4 >= 2 then 
                    ang = -360
                end
                setProperty('noteRot'..j..'.x', ang)
                doTweenX('speen'..j, 'noteRot'..j, 0, stepCrochet/150, 'cubeOut')
            end
            setProperty('scale.x', 1)
            doTweenX('scale', 'scale', 0.7, stepCrochet/150, 'cubeOut')
        end
    end
    --]]
    
    --add events and stuff here



end

function introBuzz()
    if curStep < 192 then 
        if curStep % 16 == 0 or curStep % 16 == 6 then 
            if getProperty('confusion'..startMoveThing..'.angle') == 180 then 
                setProperty('confusion'..startMoveThing..'.angle', 0)
                --setProperty('strumOffset'..startMoveThing..'.angle', 0)
            else 
                setProperty('confusion'..startMoveThing..'.angle', 180)
                --setProperty('strumOffset'..startMoveThing..'.angle', -100)
            end
            
            --doTweenAngle('confusion'..startMoveThing, 'confusion'..startMoveThing, 0, (stepCrochet/1000)*3, 'cubeInOut')
            startMoveThing = (startMoveThing + 1) % 8
        end
    end
end
local frozen = false
function onEvent(tag, val1, val2)
	if tag == 'Toggle BG Freeze' then 
		frozen = not frozen
	end
end
local xOffsetShit = {-100.0, 0.0, 0.0, 100.0}
local yOffsetShit = {0.0, 100.0, -100.0, 0.0}
local trailCount = 0
function goodNoteHit(id, ndata, ntype, isSus)
    --luaDebugMode = true
    if frozen and not isSus then --trails lol
        makeLuaSpriteCopy('trail'..trailCount, 'boyfriend', getProperty('boyfriend.x'), getProperty('boyfriend.y'))
        --setProperty('trail'..trailCount..'.alpha', 0.6)
        addLuaSprite('trail'..trailCount, true)
        setObjectOrder('trail'..trailCount, getObjectOrder('boyfriendGroup'))
        doTweenAlpha('trail'..trailCount, 'trail'..trailCount, 0, crochet*0.001*4, 'cubeOut')
        doTweenX('trailscalex'..trailCount, 'trail'..trailCount..'.scale', 1.2, crochet*0.001*4, 'cubeIn')
        doTweenY('trailscaley'..trailCount, 'trail'..trailCount..'.scale', 1.2, crochet*0.001*4, 'cubeIn')
        doTweenX('trailx'..trailCount, 'trail'..trailCount, getProperty('boyfriend.x')+xOffsetShit[ndata+1], crochet*0.001*4, 'cubeOut')
        doTweenY('traily'..trailCount, 'trail'..trailCount, getProperty('boyfriend.y')+yOffsetShit[ndata+1], crochet*0.001*4, 'cubeOut')

        doTweenColor('trailcol'..trailCount, 'trail'..trailCount, '0xFF2A93E2', 0.001, 'linear')
        trailCount = trailCount + 1 
        if trailCount > 25 then 
            trailCount = 0
        end
    end
end
function opponentNoteHit(id, ndata, ntype, isSus)
    if frozen and not isSus then 
        makeLuaSpriteCopy('trail'..trailCount, 'dad', getProperty('dad.x'), getProperty('dad.y'))
        --setProperty('trail'..trailCount..'.alpha', 0.8)
        addLuaSprite('trail'..trailCount, true)
        setObjectOrder('trail'..trailCount, getObjectOrder('dadGroup'))
        doTweenAlpha('trail'..trailCount, 'trail'..trailCount, 0, crochet*0.001*4, 'cubeOut')
        doTweenX('trailscalex'..trailCount, 'trail'..trailCount..'.scale', 1.2, crochet*0.001*4, 'cubeIn')
        doTweenY('trailscaley'..trailCount, 'trail'..trailCount..'.scale', 1.2, crochet*0.001*4, 'cubeIn')

        doTweenX('trailx'..trailCount, 'trail'..trailCount, getProperty('dad.x')+xOffsetShit[ndata+1], crochet*0.001*4, 'cubeOut')
        doTweenY('traily'..trailCount, 'trail'..trailCount, getProperty('dad.y')+yOffsetShit[ndata+1], crochet*0.001*4, 'cubeOut')

        doTweenColor('trailcol'..trailCount, 'trail'..trailCount, '0xFFFF0000', 0.001, 'linear')
        trailCount = trailCount + 1 
        if trailCount > 25 then 
            trailCount = 0
        end
    end
end
function onStepHit()
    if curStep >= 704 and curStep < 1216 then
        runHaxeCode([[
            for (i in 0...game.strumLineNotes.length)
            {
                game.strumLineNotes.members[i].colorSwap.saturation = -0.95;
                game.strumLineNotes.members[i].colorSwap.brightness = -0.2;
            }
        ]])
    end
end