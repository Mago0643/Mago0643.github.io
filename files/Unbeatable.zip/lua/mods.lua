---@diagnostic disable: undefined-field, undefined-global, lowercase-global, deprecated
--you can touch options here!

-- enables cool effect on screen. if your computer is potato, and if this file lags, turning this off will help you. (default: true)
local enable_shaders = true;
-- turning on this will make new lyrics that i want to put on (default: false)
local all_lyrics = false;
-- turn off if you hate game window movements. (default: true)
local window_movement = true;
-- The name says it all.
local camera_zoom = true;





is_easy_mode = false;
if GAMESTATE:GetCurrentSteps(0):GetDifficulty()==1 then
	is_easy_mode = true;
end

if not P1 or not P2 then
	backToSongWheel('Two Player Mode Required')
	return
end
if not FUCK_EXE or tonumber(GAMESTATE:GetVersionDate()) <= FUCK_VERSION_3_1 then
	backToSongWheel('Please open this file in NotITG v4.2 or higher!')
	return
end

require('helper');

-- judgment / combo proxies
for pn = 1, 2 do
	setupJudgeProxy(PJ[pn], P[pn]:GetChild('Judgment'), pn)
	setupJudgeProxy(PC[pn], P[pn]:GetChild('Combo'), pn)
end
-- player proxies
for pn = 1, #PP do
	PP[pn]:SetTarget(P[pn])
	P[pn]:hidden(1)
end
PPL = {}
PPS = {}
for pn = 1, #PL do
	PPL[pn] = SCREENMAN:GetTopScreen():GetChild('LifeP'..pn);
	PL[pn]:SetTarget(PPL[pn]);
end
for pn = 1, #PS do
	PPS[pn] = SCREENMAN:GetTopScreen():GetChild('ScoreP'..pn);
	PS[pn]:SetTarget(PPS[pn]);
end

-- mod aliases / custom mods
definemod {'firey', function(p)
	Firebars:y(p);
end}

plr = {1, 2, 3}
setdefault {4, 'xmod', 100, 'halgun', 100, 'stealthpastreceptors', 100, 'hidemines', sh, 'firey', 500, 'arrowpathwidth', 500, 'arrowpathdrawsizeback', 100, 'globalmodtimer', 100, 'dizzyholds'}
-- funny number
set {-69, 100, 'stealth', 100, 'dark'}
local noBitches = false;
local screen = SCREENMAN:GetTopScreen();

-- player setup
P3:SetAwake(true);
P3:hidden(0);
P3:GetChild("Judgment"):x2(9e9);
P3:GetChild("Combo"):x2(9e9);
P1:x(scx + 160);
P3:x(scx - 160);
-- causes a divide by zero crash in easy mode
--[[P3:SetNoteData(0)
P1:SetNoteData(1)
P2:SetNoteData(1)]]
P3:SetNoteDataFromLua(getSysNotedata())
P1:SetNoteDataFromLua(getBFNotedata())
P2:SetNoteDataFromLua(getBFNotedata())
P3:SetInputPlayer(2)
P2:GetChild("Judgment"):x2(75);
P2:GetChild("Combo"):x2(75);
P1:GetChild("Judgment"):x2(scx-75);
P1:GetChild("Combo"):x2(scx-75);
PPS[1]:addx(100);
PPS[2]:addx(-125);
PPL[1]:addx(100);
PPL[2]:addx(-125);

-- shaders / AFT Setup
if enable_shaders then
	aft(AngelAFT);
	sprite(AngelShader);
	AngelShader:SetTexture(AngelAFT:GetTexture());
	AngelShader:GetShader():uniform1f('stronk', 0);
	AngelShader:GetShader():uniform2f('pixel', 1, 1);
	aft(MarioAFT);
	sprite(MarioShader);
	MarioShader:SetTexture(MarioAFT:GetTexture());
	aft(CRTAFT);
	sprite(CRTShader);
	CRTShader:SetTexture(CRTAFT:GetTexture());
	aft(BorderAFT);
	sprite(BorderShader);
	BorderShader:SetTexture(BorderAFT:GetTexture());
	aft(StaticAFT);
	sprite(StaticShader);
	StaticShader:SetTexture(StaticAFT:GetTexture());
	local lol = StaticShader:GetShader();
	lol:uniform1f('speed', 10);
	lol:uniform1f('minStrength', 0.25);
	lol:uniform1f('maxStrength', 0.25);
end

-- Other Setups
func_ease {0, 16, linear, 1, 0, 'Cover:diffusealpha'}
aft(CameraAFT);
sprite(CameraSpr);
CameraSpr:SetTexture(CameraAFT:GetTexture());
CameraSpr:diffusealpha(0)
CameraCover:zoomto(sw*2,sh*2)
CameraCover:diffuse(0,0,0,1)
CameraCover:xy(scx,scy)
CameraSpr:diffusealpha(1)
Cover:diffuse(0,0,0,1);
Cover:xywh(scx,scy,sw,sh)
Crosshair:xy(scx,scy);
Crosshair:zoom(15)
Crosshair:hidden(1);
Crosshair:texturefiltering(false);
BGCover:xywh(scx,scy,sw,sh);
BGCover:diffuse(0,0,0,0)
for i = 1, #Level do
	Level[i]:xy(scx,scy-50);
	Level[i]:diffusealpha(0)
end
for i = 0, #Fire do
	Fire[i]:xy(115+75*(i+1),sh);
	Fire[i]:zoom(3);
	Fire[i]:hidden(1);
	Fire[i]:texturefiltering(false);
end
for i = 1, #Firebar do
	local offset = i%2 == 0 and -150 or 150
	Firebar[i]:xy((scx + 160) + offset,100*i);
	Firebar[i]:zoom(3);
	Firebar[i]:texturefiltering(false);
end
Firebars:y(sh);
for i = 1, #RotateL do
	RotateL[i]:zoom(0.4);
	RotateL[i]:xy(scx - 225, 200 * i);
	RotateL[i]:texturefiltering(false);
	RotateL[i]:hidden(1);
end
for i = 1, #RotateR do
	RotateR[i]:zoom(0.4);
	RotateR[i]:zoomx(-0.4);
	RotateR[i]:xy(scx + 250, 200 * i);
	RotateR[i]:texturefiltering(false);
	RotateR[i]:hidden(1)
end

for i = 1, #BirdL do
	BirdL[i]:zoom(0.4);
	BirdL[i]:xy(scx - 200, 200 * i);
	BirdL[i]:texturefiltering(false);
	BirdL[i]:hidden(1);
end
for i = 1, #BirdR do
	BirdR[i]:zoom(0.4);
	BirdR[i]:zoomx(-0.4);
	BirdR[i]:xy(scx + 225, 200 * i);
	BirdR[i]:texturefiltering(false);
	BirdR[i]:hidden(1);
end

for i = 1, #LakituL do
	LakituL[i]:zoom(0.4);
	LakituL[i]:xy(scx - 200, 200 * i);
	LakituL[i]:texturefiltering(false);
	LakituL[i]:hidden(1);
end
for i = 1, #LakituR do
	LakituR[i]:zoom(0.4);
	LakituR[i]:zoomx(-0.4);
	LakituR[i]:xy(scx + 225, 200 * i);
	LakituR[i]:texturefiltering(false);
	LakituR[i]:hidden(1);
end
FakeLakitu:zoom(0.4);
FakeLakitu:xy(sw+100,scy);
FakeLakitu:texturefiltering(false);
FakeBird:zoom(0.4);
FakeBird:xy(-100,scy);
FakeBird:texturefiltering(false);

-- utility functions
function goCenter(beat)
	func_ease {beat, 4, inOutCubic, scx+160, scx, 'P2:x'}
	func_ease {beat, 4, inOutCubic, scx+160, scx, 'P1:x'}
	func_ease {beat, 4, inOutCubic, 75, 0, 'P2:GetChild("Judgment"):x2'}
	func_ease {beat, 4, inOutCubic, scx-75, 0, 'P1:GetChild("Judgment"):x2'}
	func_ease {beat, 4, inOutCubic, 75, 0, 'P2:GetChild("Combo"):x2'}
	func_ease {beat, 4, inOutCubic, scx-75, 0, 'P1:GetChild("Combo"):x2'}
	ease {beat, 2, inOutQuad, 100, 'stealth', 100, 'dark', 1, 'hidenoteflash', plr=3}
end
function reset(beat)
	func {beat, function()
		P2:GetChild("Judgment"):x2(75);
		P2:GetChild("Combo"):x2(75);
		P1:GetChild("Judgment"):x2(scx-75);
		P1:GetChild("Combo"):x2(scx-75);
		P1:x(scx + 160);
		P2:x(scx + 160);
	end}
	set {beat, 0, 'stealth', 0, 'dark', 0, 'hidenoteflash', plr=3}
end
local loopBG = 0;
function fuckBarBG()
	barBG:linear(4);
	barBG:x(scx + 420);
	barBG:rotationz(-35);
	barBG:linear(2);
	barBG:rotationz(20);
	barBG:linear(2);
	barBG:x(scx + 400);
	barBG:rotationz(30);
	barBG:linear(2);
	barBG:x(scx + 420);
	barBG:rotationz(0);
	barBG:linear(3);
	barBG:rotationz(-15);
	barBG:x(scx + 520);
	barBG:linear(1.5);
	barBG:rotationz(10);
	barBG:linear(5.5);
	barBG:x(scx - 50);
	barBG:rotationz(-40);
	barBG:linear(1.5);
	barBG:x(scx);
	barBG:rotationz(0);
end
function triggerAngelShader(beat, amp)
	func_ease {beat, 4, outCirc, amp, 0, function(p)
		AngelShader:GetShader():uniform1f('stronk', p);
	end}
end
function screenBeat(beat, len, ease, amp)
	if not camera_zoom then return end
	func_ease {beat, len, ease, amp, 1, 'CameraSpr:zoom'}
end

function SetLife(player, life)
	if GAMESTATE:IsEditMode() then return end
	screen:SetLife(player,life);
end
function GetLife(player)
	if GAMESTATE:IsEditMode() then return 0 end
	return screen:GetLife(player);
end

function showSong(beat, num)
	func_ease {beat, 0.5, outQuad, scy - 50, scy, 'Level['..num..']:y'}
	func_ease {beat, 0.5, outQuad, 0, 1, 'Level['..num..']:diffusealpha'}
	func_ease {beat+8, 2, inOutQuad, 1, 0, 'Level['..num..']:diffusealpha'}
end

RotateLeft:y(-400);
-- mods here
local elapsedTime = 0;
local alreadyAdjusted = {};
for i = 1, #Firebar do
	table.insert(alreadyAdjusted, false);
end
local fellaScrollSpeed = 2;
local score = 0;
local perp = 100;
perframe {0, 9e9, function(b,f)
	-- this is the my way to do timer thing
	elapsedTime = GAMESTATE:GetCurrentSong():GetElapsedTimeFromBeat(GAMESTATE:GetSongBeat());
	if elapsedTime >= 21.5 * loopBG then
		loopBG = loopBG + 1;
		fuckBarBG();
	end

	local fps = DISPLAY:GetFPS();
	-- fix fucking bug (goes 0 on song load)
	if fps <= 0 then fps = 1 end
	local fellassMult = 200/fps;

	if noBitches then
		platform:x(scx + math.sin(b*math.pi*0.25) * 150);
	end

	for i = 1, #Firebar do
		local animState = Firebar[i]:getstate();
		if animState == 0 and not alreadyAdjusted[i] then
			alreadyAdjusted[i] = true;
			Firebar[i]:addrotationz(i%2 == 1 and 90 or -90);
			if Firebar[i]:GetRotationZ() >= 360 then
				Firebar[i]:addrotationz(-360);
			end
			if Firebar[i]:GetRotationZ() <= -360 then
				Firebar[i]:addrotationz(360);
			end
		elseif animState > 0 then
			alreadyAdjusted[i] = false;
		end
	end
	-- CORRECT SPEED BY FPS GOD FUCKING DAMNIT
	RotateLeft:addy(fellaScrollSpeed * fellassMult);
	RotateRight:addy(-fellaScrollSpeed * fellassMult);
	BirdLeft:addy(fellaScrollSpeed * fellassMult);
	BirdRight:addy(-fellaScrollSpeed * fellassMult);
	LakituLeft:addy(fellaScrollSpeed * fellassMult);
	LakituRight:addy(-fellaScrollSpeed * fellassMult);

	if RotateRight:GetY() <= -1000 then
		RotateRight:addy(800);
	end
	if RotateLeft:GetY() >= -200 then
		RotateLeft:addy(-200);
	end
	if BirdRight:GetY() <= -1000 then
		BirdRight:addy(800);
	end
	if BirdLeft:GetY() >= -200 then
		BirdLeft:addy(-200);
	end
	if LakituRight:GetY() <= -1000 then
		LakituRight:addy(800);
	end
	if LakituLeft:GetY() >= -200 then
		LakituLeft:addy(-200);
	end

	if b >= 1549 and b <= 1551 then
		Text:settext('SCORE\n'..score);
	end

	if window_movement then
		if b >= 1268 and b < 1332 and b % 0.125 <= 0.0125 then
			DISPLAY:SetWindowX(DISPLAY_CENTER_X + math.random(-5, 5));
			DISPLAY:SetWindowY(DISPLAY_CENTER_Y+12 + math.random(-5, 5));
		elseif b >= 1332 and b < 1396 and b % 0.125 <= 0.0125 then
			DISPLAY:SetWindowX(DISPLAY_CENTER_X + math.random(-10, 10));
			DISPLAY:SetWindowY(DISPLAY_CENTER_Y+12 + math.random(-10, 10));
		elseif b>= 1564 then
			DISPLAY:SetWindowX(DISPLAY_CENTER_X + math.random(-perp, perp));
			DISPLAY:SetWindowY(DISPLAY_CENTER_Y+12 + math.random(-perp, perp));
		end
	end

	if b < 1574 then
		TimeText:settext(SecondsToMMSS(GAMESTATE:GetSongTime() + PREFSMAN:GetPreference('GlobalOffsetSeconds')));
	end
end}
if window_movement then
	func {1396, function()
		DISPLAY:SetWindowX(DISPLAY_CENTER_X);
		DISPLAY:SetWindowY(DISPLAY_CENTER_Y+12);
	end}
	func_ease {1564, 8, outExpo, 200, 0, function(p)
		perp = p
	end}
end
func {1460, function()
	for pn = 1, 2 do
		P[pn]:GetChild("Judgment"):x2(9e9);
		P[pn]:GetChild("Combo"):x2(9e9);
	end
end}
func {1564, function()
	for pn = 1, 2 do
		P[pn]:GetChild("Judgment"):x2(0);
	end
end}
func {344, function()
	for i = 1, #RotateL do
		RotateL[i]:hidden(0)
	end
	for i = 1, #RotateR do
		RotateR[i]:hidden(0)
	end
end}
func {424, function()
	for i = 1, #RotateL do
		RotateL[i]:hidden(1)
	end
	for i = 1, #RotateR do
		RotateR[i]:hidden(1)
	end
end}
for i = 64, 127 do
	screenBeat(i, 1, outCirc, 1.1);
end
for i = 136, 208 do
	screenBeat(i, 1, outCirc, 1.1);
end
for i = 216, 223 do
	screenBeat(i, 1, outCirc, 1.1);
end
for i = 232, 239 do
	screenBeat(i, 1, outCirc, 1.1);
end
for i = 248, 255 do
	screenBeat(i, 1, outCirc, 1.1);
end
for i = 264, 271 do
	screenBeat(i, 1, outCirc, 1.1);
end
for i = 344, 391 do
	screenBeat(i, 1, outCirc, 1.15);
end
fuckBarBG();

-- text triggers
-- holy shit 564 tables
local texts = {
	{4, "WE"}, {5.25, "WE ARE"}, {6.5, "WE ARE NIN"}, {7.25, "WE ARE NINTEN"}, {8, "WE ARE NINTENDO"}, {9.5, ""}, {12, "UL"}, {12.25, "ULTI"}, {12.5, "ULTIMATE"}, {13.75, "ULTIMATE GAME"}, {15, "ULTIMATE GAME SYSTEM"}, {17, ""}, {20, "WE"}, {21, "WE CHAL"}, {21.5, "WE CHALLENGE"}, {22.75, "WE CHALLENGE ALL"}, {23.75, "WE CHALLENGE ALL PLAYERS"}, {25, ""}, {28, "YOU"}, {29, "YOU CANNOT"}, {30, "YOU CANNOT BEAT"}, {31, "YOU CANNOT BEAT US"}, {32, ""},
	{128, "WE"}, {129, "WE ARE"}, {129.5, "WE ARE NIN"}, {130, "WE ARE NINTEN"}, {131, "WE ARE NINTENDO"}, {132, "CAN"}, {132.5, "CANNOT"}, {133, "CANNOT BEAT"}, {133.5, "CANNOT BEAT NIN"}, {134, "CANNOT BEAT NINTEN"}, {135, "CANNOT BEAT NINTENDO"}, {136, "CAN"}, {136.5, "CANNOT"}, {137, "CANNOT BEAT"}, {137.5, "CANNOT BEAT NIN"}, {138, "CANNOT BEAT NINTEN"}, {139, "CANNOT BEAT NINTENDO"}, {140, ""},
	{208, "YOU"}, {209, "YOU CAN"}, {209.5, "YOU CANNOT"}, {210, "YOU CANNOT BEAT"}, {211, "YOU CANNOT BEAT US"}, {212, ""},
	{216, "WE"}, {217, "WE ARE"}, {217.5, "WE ARE NIN"}, {218, "WE ARE NINTEN"}, {219, "WE ARE NINTENDO"}, {220, "WE"}, {221, "WE ARE"}, {221.5, "WE ARE NIN"}, {222, "WE ARE NINTEN"}, {223, "WE ARE NINTENDO"}, {224, ""},
	{232, "YOU"}, {233, "YOU CAN"}, {233.5, "YOU CANNOT"}, {234, "YOU CANNOT BEAT"}, {235, "YOU CANNOT BEAT US"}, {236, "YOU"}, {237, "YOU CAN"}, {237.5, "YOU CANNOT"}, {238, "YOU CANNOT BEAT"}, {239, "YOU CANNOT BEAT US"}, {240, ""},
	{248, "WE"}, {249, "WE ARE"}, {249.5, "WE ARE NIN"}, {250, "WE ARE NINTEN"}, {251, "WE ARE NINTENDO"}, {252, "WE"}, {253, "WE ARE"}, {253.5, "WE ARE NIN"}, {254, "WE ARE NINTEN"}, {255, "WE ARE NINTENDO"}, {256, ""},
	{264, "YOU"}, {265, "you can"}, {265.5, 'you cannot'}, {266, 'you cannot beat'}, {267, 'you cannot beat us'}, {268, 'you'}, {269, 'you can'}, {269.5, 'you cannot'}, {270, 'you cannot beat'}, {271, 'you cannot beat us'}, {272, ""},
	{336, "we"}, {337, "we are"}, {338, 'we are nin'}, {338.5, 'we are ninten'}, {339, 'we are nintendo'}, {340, "you\nyou"}, {341, 'you can\nyou can'}, {341.5, 'you cannot\nyou cannot'}, {342, 'you cannot beat\nyou cannot beat'}, {343, 'you cannot beat us\nyou cannot beat us'}, {344, ""},
	--do d-do do pla e not e not do d-do do pla e not e no-not do d-do do pla e not e not do d-do do pla e not e ven one!
	--e ven one!
	{372, "you"}, {373, 'you can'}, {373.5, 'you cannot'}, {374, 'you cannot beat'}, {375, 'you cannot beat us'}, {376, ""},

	{428, "aim"}, {429.25, 'aim your'}, {430.75, 'aim your zap'}, {431.25, 'aim your zapper'}, {431.75, 'aim your zapper gun'}, {432.5, ""},
	{434, "YOU"}, {435.5, "YOU CAN"}, {436.25, "YOU CANNOT"}, {437, "YOU CANNOT BEAT"}, {437.75, "YOU CANNOT BEAT US"}, {439, ""},

	{536, "you"}, {537, "you can"}, {537.5, 'you cannot'}, {538, 'you cannot beat'}, {539, 'you cannot beat us'}, {540, ''},
	{541, 'can'}, {541.5, 'cannot'}, {542, 'cannot beat'}, {543, 'cannot beat us'}, {544, 'you'}, {545, 'you can'}, {545.5, 'you cannot'}, {546, 'you cannot beat'}, {547, 'you cannot beat us'}, {548, ''},
	{549, 'can'}, {549.5, 'cannot'}, {550, 'cannot beat'}, {551, 'cannot beat us'}, {552, ''}, {788, ''},

	{789.75, 'dis'}, {790.5, 'discover'}, {791.5, 'discover new'}, {792.75, 'discover new worlds!'}, {794, ''}, {795.75, 'you'}, {797.5, 'you can'}, {797.75, 'you cannot'}, {799.25, 'you cannot beat'}, {800.75, 'you cannot beat us'}, {802, ''},
	{816, 'you'}, {817, 'you can'}, {817.5, 'you cannot'}, {818, 'you cannot beat'}, {819, 'you cannot beat us'}, {820, ''}, {1030, ''}, {1078, ''}, {1106, ''},
	{852, 'you'}, {853, 'you can'}, {853.5, 'you cannot'}, {854, 'you cannot beat'}, {855, 'you cannot beat us'}, {856, ''},
	{860, 'you'}, {861, 'you can'}, {861.5, 'you cannot'}, {862, 'you cannot beat'}, {863, 'you cannot beat us'},
	{864, 'you'}, {865, 'you can'}, {865.5, 'you cannot'}, {866, 'you cannot beat'}, {867, 'you cannot beat us'}, {868, ''},
	{1184, 'you'}, {1185, 'you can'}, {1185.5, 'you cannot'}, {1186, 'you cannot beat'}, {1187, 'you cannot beat us'},
	{1188, 'you'}, {1189, 'you can'}, {1189.5, 'you cannot'}, {1190, 'you cannot beat'}, {1191, 'you cannot beat us'},
	{1192, 'you'}, {1193, 'you can'}, {1193.5, 'you cannot'}, {1194, 'you cannot beat'}, {1195, 'you cannot beat us'},
	{1196, 'you'}, {1197, 'you can'}, {1197.5, 'you cannot'}, {1198, 'you cannot beat'}, {1199, 'you cannot beat us'},
	{1200, 'you'}, {1201, 'you can'}, {1201.5, 'you cannot'}, {1202, 'you cannot beat'}, {1203, 'you cannot beat us'}, {1204, ''},
	{1228, 'we'}, {1228.75, 'we are'}, {1229.5, 'we are nin'}, {1230.25, 'we are ninten'}, {1231, 'we are nintendo'},
	{1232, 'you'}, {1232.75, 'you can'}, {1233.5, 'you cannot'}, {1234.25, 'you cannot beat'}, {1235, 'you cannot beat us'}, {1235.5, 'uoy tonnac taeb su'}, {1235.75, 'you cannot undertale yellow'}, {1268, ''},
	{1284, 'beat'}, {1284.5, 'us'}, {1285, ''},
	{1287.5, 'not'}, {1288, 'beat'}, {1288.5, 'us'}, {1289, ''},
	{1291.5, 'can'}, {1292, 'beat'}, {1292.5, 'us'}, {1293, ''},
	{1295.5, 'you'}, {1296, 'beat'}, {1296.5, 'us'}, {1297, ''}, {1332, ''},

	{1335, 'beat'}, {1335.5, 'us'}, {1336, ''},
	{1339, 'can'}, {1339.5, 'not'}, {1340, ''},
	{1342.5, 'can'}, {1343, 'not'}, {1343.5, 'notnotnotnotnotnotnot'}, {1344, ''},
	{1346.5, 'you'}, {1347, 'beat'}, {1347.5, 'us'}, {1348, ''}, {1396, ''},

	{1524, 'aim'}, {1525, 'aim your'}, {1526, 'aim your zap'}, {1526.5, 'aim your zapper'}, {1527, 'aim your zapper gun'},
	{1528, 'you'}, {1529, 'you can'}, {1529.5, 'you cannot'}, {1530, 'you cannot beat'}, {1531, 'you cannot beat us'},
	{1532, 'e'}, {1532.5, 'even'}, {1533, 'even with'}, {1533.5, 'even with your'}, {1534, 'even with your ro'}, {1534.5, 'even with your robot'}, {1535, 'even with your robot part'}, {1535.5, 'even with your robot partner?'},
	{1536, 'YOU'}, {1537, 'YOU CAN'}, {1537.5, 'YOU CANNOT'}, {1538, 'YOU CANNOT BEAT'}, {1539, 'YOU CANNOT BEAT US'},
	{1540, 'DIS'}, {1541, 'DISCO'}, {1541.5, 'DISCOVER'}, {1542, "DISCOVER NEW"}, {1543, "DISCOVER NEW WORLDS!"},
	{1544, 'YOU'}, {1545, 'YOU CAN'}, {1545.5, 'YOU CANNOT'}, {1546, 'YOU CANNOT BEAT'}, {1547, 'YOU CANNOT BEAT US'},
	{1548, 'SCORE'}, {1552, 'YOU'}, {1553, 'YOU CAN'}, {1553.5, 'YOU CANNOT'}, {1554, 'YOU CANNOT BEAT'}, {1555, 'YOU CANNOT BEAT US'},
	{1556, 'WE\nWE'}, {1557, 'WE ARE\nWE ARE'}, {1557.5, 'WE ARE NIN\nWE ARE NIN'}, {1558, 'WE ARE NINTEN\nWE ARE NINTEN'}, {1559, 'WE ARE NINTENDO\nWE ARE NINTENDO'},
	{1560, 'YOU\nYOU\nYOU\nYOU\nYOU'}, {1561, 'YOU CAN\nYOU CAN\nYOU CAN\nYOU CAN\nYOU CAN'}, {1561.5, 'YOU CANNOT\nYOU CANNOT\nYOU CANNOT\nYOU CANNOT\nYOU CANNOT'}, {1562, 'YOU CANNOT BEAT\nYOU CANNOT BEAT\nYOU CANNOT BEAT\nYOU CANNOT BEAT\nYOU CANNOT BEAT'},
	{1563, 'YOU CANNOT BEAT US\nYOU CANNOT BEAT US\nYOU CANNOT BEAT US\nYOU CANNOT BEAT US\nYOU CANNOT BEAT US'}, {1564, ''}
};

if all_lyrics then
	local ok = addUselessLyrics();
	for i = 1, #ok do
		table.insert(texts, ok[i]);
	end
end

for i = 756, 780, 8 do
	table.insert(texts, {i, "you"});
	table.insert(texts, {i+1, "you can"});
	table.insert(texts, {i+1.5, "you cannot"});
	table.insert(texts, {i+2, "you cannot beat"});
	table.insert(texts, {i+3, "you cannot beat us"});
	table.insert(texts, {i+4.5, "you"});
	table.insert(texts, {i+5, "you can"});
	table.insert(texts, {i+5.5, "you cannot"});
	table.insert(texts, {i+6, "you cannot beat"});
	table.insert(texts, {i+7, "you cannot beat us"});
end

for i = 998, 1022, 8 do
	table.insert(texts, {i, "you"});
	table.insert(texts, {i+1, "you can"});
	table.insert(texts, {i+1.5, "you cannot"});
	table.insert(texts, {i+2, "you cannot beat"});
	table.insert(texts, {i+3, "you cannot beat us"});
	table.insert(texts, {i+4.5, "you"});
	table.insert(texts, {i+5, "you can"});
	table.insert(texts, {i+5.5, "you cannot"});
	table.insert(texts, {i+6, "you cannot beat"});
	table.insert(texts, {i+7, "you cannot beat us"});
end

for i = 1062, 1070, 8 do
	table.insert(texts, {i, "you"});
	table.insert(texts, {i+1, "you can"});
	table.insert(texts, {i+1.5, "you cannot"});
	table.insert(texts, {i+2, "you cannot beat"});
	table.insert(texts, {i+3, "you cannot beat us"});
	table.insert(texts, {i+4.5, "you"});
	table.insert(texts, {i+5, "you can"});
	table.insert(texts, {i+5.5, "you cannot"});
	table.insert(texts, {i+6, "you cannot beat"});
	table.insert(texts, {i+7, "you cannot beat us"});
end

for i = 1094, 1102, 8 do
	table.insert(texts, {i, "you"});
	table.insert(texts, {i+1, "you can"});
	table.insert(texts, {i+1.5, "you cannot"});
	table.insert(texts, {i+2, "you cannot beat"});
	table.insert(texts, {i+3, "you cannot beat us"});
	if i ~= 1102 then
		table.insert(texts, {i+4.5, "you"});
		table.insert(texts, {i+5, "you can"});
		table.insert(texts, {i+5.5, "you cannot"});
		table.insert(texts, {i+6, "you cannot beat"});
		table.insert(texts, {i+7, "you cannot beat us"});
	end
end

for i = 1236, 1260, 8 do
	table.insert(texts, {i, "you   you"});
	table.insert(texts, {i+1, "can   can"});
	table.insert(texts, {i+1.5, "cannot   cannot"});
	table.insert(texts, {i+2, "beat   beat"});
	table.insert(texts, {i+3, "us   us"});
	table.insert(texts, {i+4.5, "you   you"});
	table.insert(texts, {i+5, "can   can"});
	table.insert(texts, {i+5.5, "cannot   cannot"});
	table.insert(texts, {i+6, "beat    beat"});
	table.insert(texts, {i+7, "us   us"});
end

for i = 1300, 1324, 8 do
	table.insert(texts, {i, "you   you"});
	table.insert(texts, {i+1, "can   can"});
	table.insert(texts, {i+1.5, "cannot   cannot"});
	table.insert(texts, {i+2, "beat   beat"});
	table.insert(texts, {i+3, "us   us"});
	table.insert(texts, {i+4.5, "you   you"});
	table.insert(texts, {i+5, "can   can"});
	table.insert(texts, {i+5.5, "cannot   cannot"});
	table.insert(texts, {i+6, "beat    beat"});
	table.insert(texts, {i+7, "us   us"});
end

for i = 1364, 1388, 8 do
	table.insert(texts, {i, "you   you"});
	table.insert(texts, {i+1, "can   can"});
	table.insert(texts, {i+1.5, "cannot   cannot"});
	table.insert(texts, {i+2, "beat   beat"});
	table.insert(texts, {i+3, "us   us"});
	table.insert(texts, {i+4.5, "you   you"});
	table.insert(texts, {i+5, "can   can"});
	table.insert(texts, {i+5.5, "cannot   cannot"});
	table.insert(texts, {i+6, "beat    beat"});
	table.insert(texts, {i+7, "us   us"});
end

for _,v in ipairs(texts) do
	local beat = v[1];
	local text = v[2];
	func {beat, function()
		Text:settext(string.upper(text));
		if text ~= "" and beat < 1560 then
			if beat <= 1172 then
				Text:diffuse(248/255, 120/255, 88/255, 1);
				Text:sleep(0.1);
			end
			if (beat >= 1200 and beat <= 1204) or (beat >= 1528 and beat < 1532) or (beat >= 1536 and beat < 1540) or (beat >= 1544 and beat < 1556) then
				Text:diffuse(0,0,0,1);
				TimeText:diffuse(0,0,0,1);
			else
				Text:diffuse(1,1,1,1);
				TimeText:diffuse(1,1,1,1);
			end
		end
		for i = 1, #BirdL do
			BirdL[i]:setstate(0);
		end
		for i = 1, #BirdR do
			BirdR[i]:setstate(0);
		end
		for i = 1, #LakituL do
			LakituL[i]:setstate(0);
		end
		for i = 1, #LakituR do
			LakituR[i]:setstate(0);
		end
		if beat >= 1184 and beat < 1188 then
			FakeLakitu:setstate(0);
		end
		if beat >= 1192 and beat < 1196 then
			FakeBird:setstate(0);
		end
	end}
	if ((beat >= 444 and beat <= 900) or (beat >= 1054 and beat <= 1078)) and text ~= "" then
		if string.lower(text) == "you cannot beat" then
			func_ease {beat, .5, linear, 10, 2, function(p) fellaScrollSpeed = p end}
		elseif string.lower(text) == "you cannot beat us" then
			func_ease {beat, .5, linear, -10, 2, function(p) fellaScrollSpeed = p end}
		end
	end
	if beat >= 1094 and beat <= 1106 and text == "you" then
		func_ease {beat, .5, linear, 10, 2, function(p) fellaScrollSpeed = p end}
	end
end

-- bg triggers maybe
local duckBGTrigger = {455, 487}
for i = 537, 581, 2 do
	table.insert(duckBGTrigger, i);
end
for i = 593, 655, 2 do
	if i ~= 607 then
		table.insert(duckBGTrigger, i);
	end
end
for _,v in ipairs(duckBGTrigger) do
	func {v, function()
		duckBG:diffuse(216/255,84/255,84/255,1);
		duckBG:sleep(0.2);
		duckBG:diffuse(85/255, 149/255, 218/255, 1);
		CameraSpr:vibrate();
		CameraSpr:effectmagnitude(10,10,10);
		SetLife(0, GetLife(0) - 0.025);
		SetLife(1, GetLife(1) - 0.025);
	end}
	func {v+0.4, function()
		CameraSpr:stopeffect();
	end}
end

ease {28, 4, linear, 0, 'dark', 0, 'stealth'}
goCenter(340)
reset(424)

func {722, function()
	P1:x(scx);
	P2:x(scx);
	P1:GetChild('Judgment'):x2(0);
	P2:GetChild('Judgment'):x2(0);
	P1:GetChild('Combo'):x2(0);
	P2:GetChild('Combo'):x2(0);
end}

set {722, 100, 'stealth', 100, 'dark', 100, 'hidenoteflash', plr=3}
reset(788)

goCenter(995)
set {1106, 150, 'cmod'}
set {1200, 0, 'cmod'}
if not is_easy_mode then
	ease {1268, 2, outExpo, 100, 'tipsy'}
	ease {1428, 32, inOutQuad, 100, 'tipsy', 100, 'sawtooth'}
	ease {1460, 1, inOutQuad, 25, 'tipsy', 100, 'beat', 50, 'sawtooth', -50, 'digital', 50, 'bumpy', 50, 'sudden', 75, 'suddenoffset', 25, 'longholds', -100, 'drawsizeback'}
else
	ease {1428, 32, inOutQuad, 100, 'tipsy'}
	ease {1460, 1, inOutQuad, 25, 'tipsy', 100, 'beat', 50, 'bumpy', 25, 'longholds', -100, 'drawsizeback'}
end

func {1428, function()
	P3:x(scx);
end}
set {1428, 0, 'hidenoteflash', plr=3}
ease {1428, 42, outBounce, -125, 'flip', 125, 'invert', 75, 'dark', 50, 'stealth', plr=3}

local bumpbeats = {1444, 1448, 1452, 1454, 1456, 1458, 1458.5, 1459, 1459.5};
for _,v in ipairs(bumpbeats) do
	set {v, 100, 'z'}
	ease {v, 2, inOutQuad, 0, 'z'}
end

for i = 1460, 1490 do
	set {i, -25, 'flip', plr={1,2}}
	ease {i, 2, outExpo, 0, 'flip', plr={1,2}}
end

for i = 1492, 1523 do
	set {i, -25, 'flip', plr=3}
	ease {i, 2, outExpo, 0, 'flip', plr=3}
end

ease {1491, 1, outBounce, -125, 'flip', 125, 'invert', plr={1,2}}
ease {1491, 1, inOutQuad, 0, 'flip', 0, 'invert', plr=3}
ease {1524, 2, outExpo, 100, 'dark', plr={1,2}}
ease {1524, 2, outExpo, 0, 'bumpy', 0, 'cubicz', 0, 'digital', 0, 'sawtooth'}
ease {1556, 2, outExpo, 100, 'dark', 100, 'stealth', 1, 'hidenoteflash', plr=3}
set {1556, 0, 'flip', 0, 'invert', 100, 'centered', -200, 'mini', 9e9, 'movex0', 9e9, 'movex2', -100, 'movex3', plr={1,2}}
ease {1562, 2, inOutQuad, 0, 'dark', plr={1,2}}
set {1564, 100, 'dark'}
set {1556, 0, 'tipsy'}
set {1523.5, 500, 'beat'}
set {1555.5, 0, 'beat'}
for i = 1525, 1539, 2 do
	set {i, -200, 'tiny', 10000, 'zoomz'}
	ease {i, 2, outExpo, 0, 'tiny', 0, 'zoomz'}
end
for i = 1540, 1547 do
	set {i, -200, 'tiny', 10000, 'zoomz'}
	ease {i, 2, outExpo, 0, 'tiny', 0, 'zoomz'}
	if i % 2 == 1 then
		set {i, math.rad(360)*100, 'confusionoffset'}
	else
		set {i, -math.rad(360)*100, 'confusionoffset'}
	end
	ease {i, 2, outExpo, 0, 'confusionoffset'}
end
for i = 1548, 1555.5, 0.5 do
	set {i, -100, 'tiny', 7500, 'zoomz'}
	ease {i, 2, outExpo, 0, 'tiny', 0, 'zoomz'}
end
for i = 344, 372, 4 do
	triggerAngelShader(i, 0.1);
end

local fuck = {376, 377, 378, 378.5, 379, 384, 385, 386, 386.5, 387, 392, 393.5, 395, 400, 401.5, 403, 408, 409.5, 411, 416, 417.5, 419}
for _,v in ipairs(fuck) do
	triggerAngelShader(v, 0.125);
end
local screen2 = {392, 393.5, 395, 396, 397, 398, 399, 400, 401.5, 403, 404, 405, 406, 407, 408, 409.5, 411, 412, 413, 414, 415, 416, 417.5, 419, 420, 421, 422, 423, 424};
for _,v in ipairs(screen2) do
	screenBeat(v, 1, outCirc, 1.15);
end

-- we do a little trolling
ease {375, 2, inOutExpo, 100, 'reverse'}
ease {376, 2, inOutExpo, 0, 'reverse'}
if not is_easy_mode then
	ease {377, 2, inOutExpo, 100, 'split'}
	ease {377.5, 2, inOutExpo, 100, 'reverse', 0, 'split'}
	ease {378, 2, inOutExpo, 0, 'reverse'}
end

ease {383, 2, inOutExpo, 100, 'reverse'}
ease {384, 2, inOutExpo, 0, 'reverse'}
if not is_easy_mode then
	ease {385, 2, inOutExpo, -100, 'split', 100, 'reverse'}
	ease {385.5, 2, inOutExpo, 0, 'split'}
	ease {386, 2, inOutExpo, 0, 'reverse', 0, 'split'}
end

if not is_easy_mode then
	ease {392, 2, outExpo, 45, 'rotationy'}
	ease {393.5, 2, outExpo, 45, 'rotationx'}
	ease {395, 2, outExpo, 45, 'rotationz'}
	--ease {396, 2, outExpo, 0, 'rotationz', 0, 'rotationy', 0, 'rotationx', 0, 'confusionyoffset', 0, 'confusionxoffset', 0, 'confusionoffset'}

	ease {400, 2, outExpo, -45, 'rotationy', 0, 'rotationx', 0, 'rotationz'}
	ease {401.5, 2, outExpo, -45, 'rotationx'}
	ease {403, 2, outExpo, -45, 'rotationz'}
	--ease {404, 2, outExpo, 0, 'rotationz', 0, 'rotationy', 0, 'rotationx', 0, 'confusionyoffset', 0, 'confusionxoffset', 0, 'confusionoffset'}

	ease {408, 2, outExpo, 45, 'rotationy', 0, 'rotationx', 0, 'rotationz'}
	ease {409.5, 2, outExpo, 45, 'rotationx'}
	ease {411, 2, outExpo, 45, 'rotationz'}

	ease {416, 2, outExpo, -45, 'rotationy', 0, 'rotationx', 0, 'rotationz'}
	ease {417.5, 2, outExpo, -45, 'rotationx'}
	ease {419, 2, outExpo, -45, 'rotationz'}
	ease {424, 2, outExpo, 0, 'rotationz', 0, 'rotationx', 0, 'rotationy'}
end
-- yeet the old arrow rotation thing
-- lesgo superpowered counter rotation (https://xerool.github.io/mirin-template/docs/doc-aux.html#node)
alias {'confusionzoffset', 'confusionoffset'}
local sin, cos = math.sin, math.cos
local asin, atan2 = math.asin, math.atan2
local pi = math.pi
node {
    'rotationx', 'rotationy', 'rotationz',
    'confusionxoffset', 'confusionyoffset', 'confusionoffset',
    function(rx, ry, rz, cx, cy, cz)
        -- transform axes
        rx, rz = rz, rx
        cx, cz = cz, cx
        
        -- helpers for r
        local rcosx, rcosy, rcosz, rsinx, rsiny, rsinz =
            cos(rx / 360 * pi), cos(ry / 360 * pi), cos(rz / 360 * pi),
            sin(rx / 360 * pi), sin(ry / 360 * pi), sin(rz / 360 * pi)
        
        -- r to quaternion
        local ra, rb, rc, rd =
            rcosx*rcosy*rcosz-rsinx*rsiny*rsinz,
            rsinx*rsiny*rcosz+rcosx*rcosy*rsinz,
            rsinx*rcosy*rcosz+rcosx*rsiny*rsinz,
            rcosx*rsiny*rcosz-rsinx*rcosy*rsinz
        
        -- helpers for c
        local ccosx, ccosy, ccosz, csinx, csiny, csinz =
            cos(cx/200), cos(cy/200), cos(cz/200),
            sin(cx/200), sin(cy/200), sin(cz/200)
        
        -- c to quaternion
        local ca, cb, cc, cd =
            ccosx*ccosy*ccosz-csinx*csiny*csinz,
            csinx*csiny*ccosz+ccosx*ccosy*csinz,
            csinx*ccosy*ccosz+ccosx*csiny*csinz,
            ccosx*csiny*ccosz-csinx*ccosy*csinz
        
        -- o = c * inverse(r)
        local oa, ob, oc, od =
            ca*ra+cb*rb+cc*rc+cd*rd,
            -ca*rb+cb*ra-cc*rd+cd*rc,
            -ca*rc+cb*rd+cc*ra-cd*rb,
            -ca*rd-cb*rc+cc*rb+cd*ra
        
        -- o to euler angles
        local ox, oy, oz =
            100 * atan2(2*oc*oa-2*ob*od, 1-2*oc*oc-2*od*od),
            100 * asin(2*ob*oc+2*od*oa),
            100 * atan2(2*ob*oa-2*oc*od, 1-2*ob*ob-2*od*od)
        
        -- transform axes
        ox, oz = oz, ox
        return ox, oy, oz
    end,
    'confusionxoffset', 'confusionyoffset', 'confusionoffset',
}

set {423.5, 0, 'beat'}
set {28, 100, 'drunk'}
ease {63, 1, outCirc, 0, 'drunk'}
set {63.5, 100, 'beat'}
set {271.5, 0, 'beat'}
set {343.5, 100, 'beat'}

set {306, -200, 'tiny', 100, 'drunk', 600, 'cubicx'}
ease {306, 2, outExpo, 0, 'tiny', 0, 'drunk', 0, 'cubicx'}
set {307, -200, 'tiny', -100, 'drunk', -600, 'cubicx'}
ease {307, 2, outExpo, 0, 'tiny', 0, 'drunk', 0, 'cubicx'}
set {314, -200, 'tiny', 100, 'drunk', 600, 'cubicx'}
ease {314, 2, outExpo, 0, 'tiny', 0, 'drunk', 0, 'cubicx'}
set {315, -200, 'tiny', -100, 'drunk', -600, 'cubicx'}
ease {315, 2, outExpo, 0, 'tiny', 0, 'drunk', 0, 'cubicx'}

if not is_easy_mode then
	set {322, -200, 'tiny', 100, 'drunk', 600, 'cubicx'}
	ease {322, 2, outExpo, 0, 'tiny', 0, 'drunk', 0, 'cubicx'}
	set {323, -200, 'tiny', -100, 'drunk', -600, 'cubicx'}
	ease {323, 2, outExpo, 0, 'tiny', 0, 'drunk', 0, 'cubicx'}
	set {330, -200, 'tiny', 100, 'drunk', 600, 'cubicx'}
	ease {330, 2, outExpo, 0, 'tiny', 0, 'drunk', 0, 'cubicx'}
	set {331, -200, 'tiny', -100, 'drunk', -600, 'cubicx'}
	ease {331, 2, outExpo, 0, 'tiny', 0, 'drunk', 0, 'cubicx'}
end

set {334, -math.rad(360)*100, 'confusionoffset'}
ease {334, 1, bounce, -100, 'skewx', 100, 'noteskewx'}
ease {334, 1, outQuad, 0, 'confusionoffset'}
set {335, math.rad(360)*100, 'confusionoffset'}
ease {335, 1, outQuad, 0, 'confusionoffset'}
ease {335, 1, bounce, 100, 'skewx', -100, 'noteskewx'}
for i = 344, 375 do
	if is_easy_mode then break end
	if i%2 == 0 then
		ease {i, 2, outExpo, 100, 'tipsy'}
	else
		ease {i, 2, outExpo, -100, 'tipsy'}
	end
end
for i = 590.5, 591.5, .5 do
	ease {i, .5, bounce, -50, 'movey2', plr=3}
end
ease {376, 2, outExpo, 0, 'tipsy'}
set {455.5, 100, 'beat'}
set {687.5, 200, 'beat'}
for i = 804, 818, 2 do
	set {i, -200, 'tiny'}
	ease {i, 2, outExpo, 0, 'tiny'}
end
for i = 821, 899, 2 do
	if not is_easy_mode then
		set {i, i%2 == 0 and -200 or 200, 'drunk'}
	else
		set {i, i%2 == 0 and -100 or 100, 'drunk'}
	end
	ease {i, 2, outExpo, 0, 'drunk'}
end
if not is_easy_mode then
	ease {1106, 4, inExpo, 100, 'drunk', 100, 'tipsy'}
else
	ease {1106, 4, inExpo, 100, 'drunk'}
end
set {1184, 0, 'drunk', 0, 'tipsy', 100, 'beat'}
for i = 1204, 1267 do
	if is_easy_mode then
		screenBeat(i, 1, outExpo, 1.1)
	else
		screenBeat(i, 1, outExpo, 1.15)
	end
end
local funniBeats = {0, 1, 2, 3, 4, 4.75, 5.5, 6, 6.75, 7.5};
local flip = false;
for i = 1332, 1388, 8 do
	for _,v in ipairs(funniBeats) do
		local len = (funniBeats[_+1] and funniBeats[_+1]-v or 0.5);
		screenBeat(i+v, len, outExpo, 1.025)
		if not is_easy_mode then
			set {i+v, -25, 'invert', 25, 'flip'}
			if flip then
				set {i+v, 500, 'drunkz0', 200, 'tipsy', 500, 'drunkz2', -500, 'drunkz1', -500, 'drunkz3'}
			else
				set {i+v, -500, 'drunkz0', -200, 'tipsy', -500, 'drunkz2', 500, 'drunkz1', 500, 'drunkz3'}
			end
			ease {i+v, len, outQuad, 0, 'drunkz0', 0, 'tipsy', 0, 'invert', 0, 'flip', 0, 'drunkz1', 0, 'drunkz2', 0, 'drunkz3'}
		else
			if flip then
				ease {i+v, len, outBounce, -25, 'tiny0', 25, 'tiny1', -25, 'tiny2', 25, 'tiny3'}
			else
				ease {i+v, len, outBounce, 25, 'tiny0', -25, 'tiny1', 25, 'tiny2', -25, 'tiny3'}
			end
		end
		flip = not flip;
	end
end
set {1396, 0, 'tiny0', 0, 'tiny1', 0, 'tiny2', 0, 'tiny3'}
if is_easy_mode then
	ease {1236, 2, outElastic, 100, 'drunk'}
else
	ease {1236, 2, outElastic, 200, 'drunk'}
end
ease {1268, 2, outExpo, 0, 'drunk'}
set {1396, 0, 'beat', 100, 'drunk'}
set {1300, 25, 'expand', 100, 'arrowpath', plr={1,2}, 500, 'spiralx', 500, 'spiralz', -500, 'spiraly'}
set {1332, 0, 'expand'}
ease {1300, 4, outExpo, 0, 'arrowpath', plr={1,2}, 0, 'spiralx', 0, 'spiralz', 0, 'spiraly'}
ease {1424, 4, inExpo, 0, 'drunk'}
for i = 1428, 1456, 4 do
	set {i, 50, 'arrowpath'}
	ease {i, 4, inQuad, 0, 'arrowpath'}
end

func {344, function()
	for i = 0, #lightning do
		lightning[i]:hidden(0)
	end
end}

func {424, function()
	for i = 0, #lightning do
		lightning[i]:hidden(1)
	end
end}

set {456, 200, 'drunk'}
ease {456, 2, outExpo, 0, 'drunk'}
set {519.5, 100, 'beat'}
for i = 520, 551 do
	screenBeat(i, 2, outCirc, 1.175);
end
for i = 537, 581, 2 do
	if not is_easy_mode then
		set {i, 500, 'drunk', 500, 'tipsy'}
	else
		set {i, 100, 'drunk', 100, 'tipsy'}
	end
	ease {i, 2, outExpo, 0, 'drunk', 0, 'tipsy'}
end
set {581.5, 0, 'beat'}
for i = 552, 582 do
	if is_easy_mode then break end
	if i % 2 == 0 then
		screenBeat(i, 2, outCirc, 1.175);
	else
		screenBeat(i, 2, outCirc, 1.1);
	end
end
for i = 593, 655, 2 do
	if i ~= 607 then
		if not is_easy_mode then set {i, 500, 'drunk', 500, 'tipsy'}
		else set {i, 100, 'drunk', 100, 'tipsy'} end
		ease {i, 2, outExpo, 0, 'drunk', 0, 'tipsy'}
	end
end

func {720, function()
	Cover:diffusealpha(1);
	Crosshair:hidden(0);
end}
func {724, function()
	Cover:diffusealpha(0);
	Crosshair:hidden(1);
end}

local flashCross = {721, 722, 722.5, 723, 723.5, 724}
local isRed = false;
for _,v in ipairs(flashCross) do
	func {v, function()
		if isRed then
			Crosshair:diffuse(1,1,1,1);
		else
			Crosshair:diffuse(1,0,0,1);
		end
		isRed = not isRed;
	end}
end

set {755, 0, 'xmod', 100, 'drunk', 100, 'tipsy'}
ease {755, 2, outQuad, 4, 'xmod', 0, 'drunk', 0, 'tipsy'}
set {755.5, 100, 'beat'}
set {787.5, 0, 'beat'}

func_ease {428, 4, inOutQuad, 0, 1, 'duckBG:diffusealpha'}
func_ease {428, 4, inOutQuad, 0, 1, 'fuckGrass:diffusealpha'}
func {432, function()
	barBG:hidden(1)
end}

func_ease {432, 2, inOutQuad, -150, 150, 'duckTree:x'}
func_ease {432, 2, inOutQuad, sw+150, sw-150, 'duckBust:x'}
func {432, function()
	SetLife(0, 0.5);
	SetLife(1, 0.5);
end}
func {796, function()
	SetLife(0, 0.5);
	SetLife(1, 0.5);
end}
func {1178, function()
	SetLife(0, 0.5);
	SetLife(1, 0.5);
end}

func_ease {788, 4, inOutQuad, scy, sh*2, 'duckBG:y'}
func_ease {788, 4, inOutQuad, sh - 75, sh*2, 'fuckGrass:y'}
func_ease {788, 4, inOutQuad, scy - 50, sh*2 - 50, 'duckTree:y'}
func_ease {788, 4, inOutQuad, scy + 50, sh*2 + 50, 'duckBust:y'}

func_ease {788, 4, inOutQuad, -100, 50, 'castle2:y'}
func_ease {788.5, 4, inOutQuad, sh, scy, 'castle1:y'}
func_ease {788.5, 2, outQuad, sw+100, scx + math.sin(790.5*math.pi*0.25) * 150, 'platform:x'}
func {790.5, function() noBitches = true; end}

func_ease {795, 16, outElastic, sh+200, sh+25, 'Lava:y'}
--[[func_ease {836, 2, outQuad, sh + 120, sh - 120, 'Firebar:y'}
func_ease {964, 2, inBack, sh - 120, sh + 120, 'Firebar:y'}--]]

for i = 966, 1029 do
	if not is_easy_mode then
		if i % 2 == 0 then
			set {i, 300, 'drunk', 300, 'tipsy', 100, 'cubicx', 50, 'flip'}
		else
			set {i, -300, 'drunk', -300, 'tipsy', -100, 'cubicx', -50, 'flip', -math.rad(360)*100, 'confusionoffset', -200, 'tinyy', 100, 'tinyx'}
		end
	else
		if i % 2 == 0 then
			set {i, 100, 'drunk', 100, 'tipsy'}
		else
			set {i, -100, 'drunk', -100, 'tipsy', -25, 'flip'}
		end
	end
	ease {i, 2, outExpo, 0, 'drunk', 0, 'tipsy', 0, 'cubicx', 0, 'flip', 0, 'confusionoffset', 0, 'tinyy', 0, 'tinyx'}
end

for i = 835, 846, 2 do
	add {i, 2, outExpo, -100, 'firey'}
end
--[[for i = 903, 931, 4 do
	if i ~= 915 then
		if i % 8 == 7 then
			set {i, sh - 600, 'firey'}
			ease {i, 2, outExpo, sh - 700, 'firey'}
		else
			set {i, sh - 700, 'firey'}
			ease {i, 2, outExpo, sh - 800, 'firey'}
		end
	end
end]]

if not is_easy_mode then
	ease {1424, 4, bounce, 1, 'xmod'}
end

local switch = false;
local bSnare = {{914, true}, {914.75, false}, {915.5, true}, {930, true}, {930.75, false}, {931.5, true}};
for i = 847, 899, 2 do
	table.insert(bSnare, {i, not switch});
	switch = not switch;
end

for i = 903, 931, 4 do
	if i ~= 915 and i ~= 931 then
		table.insert(bSnare, {i, not switch});
		switch = not switch;
	else
		switch = not switch;
	end
end

for i = 933, 961, 2 do
	table.insert(bSnare, {i, not switch});
	switch = not switch;
end

for _,i in ipairs(bSnare) do
	if i[2] then
		set {i[1], sh - 600, 'firey'}
		ease {i[1], 2, outExpo, sh - 700, 'firey'}
	else
		set {i[1], sh - 700, 'firey'}
		ease {i[1], 2, outExpo, sh - 800, 'firey'}
	end
end
local bowerBGTrigger = {};
for _,i in ipairs(bSnare) do
	table.insert(bowerBGTrigger, i[1]);
end
for i = 837, 845, 2 do
	table.insert(bowerBGTrigger, i);
end
table.sort(bowerBGTrigger);
for _,i in ipairs(bowerBGTrigger) do
	func_ease {i, 1, outQuad, 0.75, 0, function(p)
		BG:diffuse(p,0,0,1);
	end}

	local nextLength = bowerBGTrigger[_+1] and bowerBGTrigger[_+1]-i or 2
	--[[func_ease {i-(nextLength*.5), (nextLength*.5), inCirc, sh+25, sh-75, 'Lava:y'}
	func_ease {i, nextLength*.5, outCirc, sh-75, sh+25, 'Lava:y'}]]
	if nextLength > 2 then nextLength = 1 end
	func_ease {i, nextLength, bounce, sh+25, sh-25, 'Lava:y'}
end

ease {964, 2, inQuad, -1500, 'firey', 0, 'tornado', 0, 'tipsy', 0, 'flip'}
if not is_easy_mode then
	ease {837, 2, inOutQuad, 25, 'tornado', 50, 'tipsy', plr={1,2}, 15, 'flip'}
else
	ease {837, 2, inOutQuad, 50, 'tipsy', plr={1,2}}
end

set {819.5, 100, 'beat'}

-- Fella movements
func_ease {348, .5, outQuad, 0, -scx-125, function(p) RotateRight:x(p); end}
func_ease {348, .5, outQuad, 0, scx+125, function(p) RotateLeft:x(p); end}
func_ease {348, .5, outQuad, 100, sw-100, function(p) lightning[0]:x(p); end}
func_ease {348, .5, outQuad, sw-100, 100, function(p) lightning[1]:x(p); end}

func_ease {352, .5, outQuad, -scx-125, 0, function(p) RotateRight:x(p); end}
func_ease {352, .5, outQuad, scx+125, 0, function(p) RotateLeft:x(p); end}
func_ease {352, .5, outQuad, sw-100, 100, function(p) lightning[0]:x(p); end}
func_ease {352, .5, outQuad, 100, sw-100, function(p) lightning[1]:x(p); end}

func_ease {356, .5, outQuad, 0, -scx-125, function(p) RotateRight:x(p); end}
func_ease {356, .5, outQuad, 0, scx+125, function(p) RotateLeft:x(p); end}
func_ease {356, .5, outQuad, 100, sw-100, function(p) lightning[0]:x(p); end}
func_ease {356, .5, outQuad, sw-100, 100, function(p) lightning[1]:x(p); end}

func_ease {360, .5, outQuad, -scx-125, 0, function(p) RotateRight:x(p); end}
func_ease {360, .5, outQuad, scx+125, 0, function(p) RotateLeft:x(p); end}
func_ease {360, .5, outQuad, sw-100, 100, function(p) lightning[0]:x(p); end}
func_ease {360, .5, outQuad, 100, sw-100, function(p) lightning[1]:x(p); end}

func_ease {376, .5, linear, 25, 2, function(p) fellaScrollSpeed = p; end}
func_ease {377, .5, linear, -12.5, 2, function(p) fellaScrollSpeed = p; end}
func_ease {378, .5, linear, 25, 2, function(p) fellaScrollSpeed = p; end}
func_ease {378.5, .5, linear, -12.5, 2, function(p) fellaScrollSpeed = p; end}
func_ease {379, .5, outQuad, 0, -scx-125, function(p) RotateRight:x(p); end}
func_ease {379, .5, outQuad, 0, scx+125, function(p) RotateLeft:x(p); end}
func_ease {379, .5, outQuad, 100, sw-100, function(p) lightning[0]:x(p); end}
func_ease {379, .5, outQuad, sw-100, 100, function(p) lightning[1]:x(p); end}

func_ease {384, .5, linear, 25, 2, function(p) fellaScrollSpeed = p; end}
func_ease {385, .5, linear, -12.5, 2, function(p) fellaScrollSpeed = p; end}
func_ease {386, .5, linear, 25, 2, function(p) fellaScrollSpeed = p; end}
func_ease {386.5, .5, linear, -12.5, 2, function(p) fellaScrollSpeed = p; end}
func_ease {387, .5, outQuad, -scx-125, 0, function(p) RotateRight:x(p); end}
func_ease {387, .5, outQuad, scx+125, 0, function(p) RotateLeft:x(p); end}
func_ease {387, .5, outQuad, sw-100, 100, function(p) lightning[0]:x(p); end}
func_ease {387, .5, outQuad, 100, sw-100, function(p) lightning[1]:x(p); end}

func_ease {392, .5, linear, 4, 0, function(p) fellaScrollSpeed = p; end}
func_ease {393.5, .5, linear, -4, 0, function(p) fellaScrollSpeed = p; end}
func_ease {393.5, .5, outQuad, 0, -scx-125, function(p) RotateRight:x(p); end}
func_ease {393.5, .5, outQuad, 0, scx+125, function(p) RotateLeft:x(p); end}
func_ease {393.5, .5, outQuad, 100, sw-100, function(p) lightning[0]:x(p); end}
func_ease {393.5, .5, outQuad, sw-100, 100, function(p) lightning[1]:x(p); end}
func_ease {395, .5, linear, 4, 0, function(p) fellaScrollSpeed = p; end}
func {396, function() fellaScrollSpeed = 2; end}

func_ease {400, .5, linear, -4, 0, function(p) fellaScrollSpeed = p; end}
func_ease {401.5, .5, linear, 4, 0, function(p) fellaScrollSpeed = p; end}
func_ease {401.5, .5, outQuad, -scx-125, 0, function(p) RotateRight:x(p); end}
func_ease {401.5, .5, outQuad, scx+125, 0, function(p) RotateLeft:x(p); end}
func_ease {401.5, .5, outQuad, sw-100, 100, function(p) lightning[0]:x(p); end}
func_ease {401.5, .5, outQuad, 100, sw-100, function(p) lightning[1]:x(p); end}
func_ease {403, .5, linear, -4, 0, function(p) fellaScrollSpeed = p; end}
func {404, function() fellaScrollSpeed = 2; end}

func_ease {408, .5, linear, 4, 0, function(p) fellaScrollSpeed = p; end}
func_ease {409.5, .5, linear, -4, 0, function(p) fellaScrollSpeed = p; end}
func_ease {409.5, .5, outQuad, 0, -scx-125, function(p) RotateRight:x(p); end}
func_ease {409.5, .5, outQuad, 0, scx+125, function(p) RotateLeft:x(p); end}
func_ease {409.5, .5, outQuad, 100, sw-100, function(p) lightning[0]:x(p); end}
func_ease {409.5, .5, outQuad, sw-100, 100, function(p) lightning[1]:x(p); end}
func_ease {411, .5, linear, 4, 0, function(p) fellaScrollSpeed = p; end}
func {412, function() fellaScrollSpeed = 2; end}

func_ease {416, .5, linear, -4, 0, function(p) fellaScrollSpeed = p; end}
func_ease {417.5, .5, linear, 4, 0, function(p) fellaScrollSpeed = p; end}
func_ease {417.5, .5, outQuad, -scx-125, 0, function(p) RotateRight:x(p); end}
func_ease {417.5, .5, outQuad, scx+125, 0, function(p) RotateLeft:x(p); end}
func_ease {417.5, .5, outQuad, sw-100, 100, function(p) lightning[0]:x(p); end}
func_ease {417.5, .5, outQuad, 100, sw-100, function(p) lightning[1]:x(p); end}
func_ease {419, .5, linear, -4, 0, function(p) fellaScrollSpeed = p; end}
func {420, function() fellaScrollSpeed = 2; end}

triggerAngelShader(756, 0.2)

func {756, function()
	lightning[0]:hidden(0)
	lightning[1]:hidden(0)
	for i = 1, #BirdL do
		BirdL[i]:hidden(0);
	end
	for i = 1, #BirdR do
		BirdR[i]:hidden(0);
	end
end}
func {788, function()
	lightning[0]:hidden(1)
	lightning[1]:hidden(1)
	for i = 1, #BirdL do
		BirdL[i]:hidden(1);
	end
	for i = 1, #BirdR do
		BirdR[i]:hidden(1);
	end
end}

-- this is spy
set {1077.5, 0, 'beat'}

func {998, function()
	lightning[0]:hidden(0)
	lightning[1]:hidden(0)
	for i = 1, #LakituL do
		LakituL[i]:hidden(0);
	end
	for i = 1, #LakituR do
		LakituR[i]:hidden(0);
	end
end}

func {1030, function()
	lightning[0]:hidden(1)
	lightning[1]:hidden(1)
	for i = 1, #LakituL do
		LakituL[i]:hidden(1);
	end
	for i = 1, #LakituR do
		LakituR[i]:hidden(1);
	end
end}

triggerAngelShader(998, 0.2);
triggerAngelShader(1062, 0.2);
triggerAngelShader(1030, 0.2);

func {1062, function()
	lightning[0]:hidden(0)
	lightning[1]:hidden(0)
	for i = 1, #LakituL do
		LakituL[i]:hidden(0);
	end
	for i = 1, #LakituR do
		LakituR[i]:hidden(0);
	end
end}

func {1106, function()
	lightning[0]:hidden(1)
	lightning[1]:hidden(1)
	for i = 1, #LakituL do
		LakituL[i]:hidden(1);
	end
	for i = 1, #LakituR do
		LakituR[i]:hidden(1);
	end
	castle1:hidden(1);
	castle2:hidden(1);
	Lava:hidden(1);
	platform:hidden(1);
	noBitches = false;
end}
triggerAngelShader(1106, 0.2)
func_ease {1078, 8, inQuad, 0, 0.75, 'BGCover:diffusealpha'}
func_ease {1106, .5, outQuad, 0, 1, 'ClownCar:diffusealpha'}
--actually use z axis?!?!?!?!
func_ease {1106, 2.5, inOutQuad, 500, 100, 'ClownCar:z'}
func_ease {1106, 4, inQuad, scy, -200, 'ClownCar:y'}
--[[func_ease {1106, 2.5, inOutQuad, 100, 2.5, 'ClownCar:zoom'}
func_ease {1107, 3, inOutExpo, scy, -100, 'ClownCar:y'}]]
func {1106.5, function()
	barBG:hidden(0)
end}
func_ease {1176, 1, linear, 0, 1, 'Cover:diffusealpha'}
func {1184, function()
	barBG:hidden(1);
	Cover:diffusealpha(0);
	BGCover:diffusealpha(0)
end}
set {1184, 100, 'dark'}
set {1204, 0, 'dark', plr={1,2}}
func {1204, function()
	barBG:hidden(0);
	BG:diffuse(0,0,0,1)
end}
triggerAngelShader(1204, 0.5)

func_ease {1183, 2, inQuad, sw+100, sw-100, 'FakeLakitu:x'}
func_ease {1191, 2, inQuad, -100, 100, 'FakeBird:x'}
func {1200, function()
	FakeBird:hidden(1);
	FakeLakitu:hidden(1);
	-- send to fake ones to the void
	FakeBird:xy(9e9, 9e9);
	FakeLakitu:xy(9e9, 9e9);

	BG:diffuse(1,1,1,1);
end}

func {1236, function()
	lightning[0]:hidden(0)
	lightning[1]:hidden(0)
	RotateLeft:x(0);
	RotateRight:x(0);
	for i = 1, #RotateL do
		RotateL[i]:hidden(0)
	end
	for i = 1, #RotateR do
		RotateR[i]:hidden(0)
	end
end}
triggerAngelShader(1236, 0.5)
triggerAngelShader(1268, 0.5)
func_ease {1236, 1, linear, 1, 0, function(p) BGCover:diffusealpha(p) end}
func_ease {1268, 1, linear, 1, 0, function(p) BGCover:diffusealpha(p) end}
func_ease {1332, 1, linear, 1, 0, function(p) BGCover:diffusealpha(p) end}
func {1268, function()
	lightning[0]:hidden(1)
	lightning[1]:hidden(1)
	for i = 1, #RotateL do
		RotateL[i]:hidden(1)
	end
	for i = 1, #RotateR do
		RotateR[i]:hidden(1)
	end
	Static:hidden(0);
	DuckGlitched:hidden(0);
end}

func {1332, function()
	CastleGlitched:hidden(0);
	for i = 1, #BirdL do
		BirdL[i]:hidden(1)
	end
	for i = 1, #BirdR do
		BirdR[i]:hidden(1)
	end
	lightning[0]:hidden(1)
	lightning[1]:hidden(1)
end}
triggerAngelShader(1332, 0.5)
func_ease {1396, 1, linear, 0.75, 0, function(p)
	Cover:diffuse(1,1,1,p);
end}
func {1396, function()
	Static:hidden(1);
	DuckGlitched:hidden(1);
	CastleGlitched:hidden(1);
	BGCover:diffuse(0,0,0,0.75)
end}

func_ease {1460, 1, linear, 1, 0, function(p) BGCover:diffusealpha(p) end}
func_ease {1476, 1, linear, 1, 0, function(p) BGCover:diffusealpha(p) end}
func_ease {1524, 1, linear, 1, 0, function(p) BGCover:diffusealpha(p) end}
func {1476, function()
	Static:hidden(0);
	DuckGlitched:hidden(0);
end}
func {1508, function()
	CastleGlitched:hidden(0);
end}
func {1524, function()
	Static:hidden(1);
	DuckGlitched:hidden(1);
	CastleGlitched:hidden(1);
end}

func {1300, function()
	lightning[0]:hidden(0)
	lightning[1]:hidden(0)
	for i = 1, #BirdL do
		BirdL[i]:hidden(0)
	end
	for i = 1, #BirdR do
		BirdR[i]:hidden(0)
	end
end}
triggerAngelShader(1300, 0.5)
triggerAngelShader(1364, 0.5)
func {1364, function()
	lightning[0]:hidden(0)
	lightning[1]:hidden(0)
	for i = 1, #LakituL do
		LakituL[i]:hidden(0)
	end
	for i = 1, #LakituR do
		LakituR[i]:hidden(0)
	end
end}
func {1396, function()
	lightning[0]:hidden(1)
	lightning[1]:hidden(1)
	for i = 1, #LakituL do
		LakituL[i]:hidden(1)
	end
	for i = 1, #LakituR do
		LakituR[i]:hidden(1)
	end
end}

func {1284, function() Text:x2(-200) end}
func {1284.5, function() Text:x2(0) end}

func {1287.5, function() Text:x2(-200) end}
func {1288, function() Text:x2(0) end}
func {1288.5, function() Text:x2(200) end}

func {1291.5, function() Text:x2(-200) end}
func {1292, function() Text:x2(0) end}
func {1292.5, function() Text:x2(200) end}

func {1295.5, function() Text:x2(-200) end}
func {1296, function() Text:x2(0) end}
func {1296.5, function() Text:x2(200) end}
func {1297, function() Text:x2(0) end}

func {1335, function() Text:x2(-100) end}
func {1335.5, function() Text:x2(200) end}

func {1339, function() Text:x2(-200) end}
func {1339.5, function() Text:x2(200) end}

func {1342.5, function() Text:x2(-200) end}
func {1343, function() Text:x2(200) end}
func {1343.5, function() Text:x2(0) end}

func {1346.5, function() Text:x2(-200) end}
func {1347, function() Text:x2(0) end}
func {1347.5, function() Text:x2(200) end}
func {1348, function() Text:x2(0) end}

ease {1524, 2, outQuad, 0, 'stealth', 0, 'dark', plr=3}

local windowMaxY = DISPLAY_CENTER_Y + 12 + (DISPLAY:GetDesktopHeight() - DISPLAY:GetWindowHeight()) / 2;
local windowMaxX = DISPLAY_CENTER_X + (DISPLAY:GetDesktopWidth() - DISPLAY:GetWindowWidth()) / 2;
func {1532, function()
	BGCover:diffuse(1,1,1,0);
end}
func {1540, function()
	BGCover:diffuse(1,1,1,0);
end}
func {1556, function()
	BGCover:hidden(1)
	barBG:hidden(1);
end}
func_ease {1549, 1, linear, 0, 1000000, function(p)
	score = math.floor(p);
end}
func {1560, function()
	Text:diffuse(1,0,0,1);
end}

func_ease {340, 2, inOutQuad, 1, 0, function(p)
	PPL[1]:diffusealpha(p);
	PPL[2]:diffusealpha(p);
	PPS[1]:diffusealpha(p);
	PPS[2]:diffusealpha(p);
end}

func {424, function()
	for i = 1, 2 do
		PPL[i]:diffusealpha(1);
		PPS[i]:diffusealpha(1);
	end
end}
func {722, function()
	for i = 1, 2 do
		PPL[i]:diffusealpha(0);
		PPS[i]:diffusealpha(0);
	end
end}
func {788, function()
	for i = 1, 2 do
		PPL[i]:diffusealpha(1);
		PPS[i]:diffusealpha(1);
	end
end}
func_ease {996, 2, inOutQuad, 1, 0, function(p)
	for i = 1, 2 do
		PPL[i]:diffusealpha(p);
		PPS[i]:diffusealpha(p);
	end
end}
func {1106, function()
	for i = 1, 2 do
		PPL[i]:diffusealpha(1);
		PPS[i]:diffusealpha(1);
	end
end}
func {1184, function()
	for i = 1, 2 do
		PPL[i]:diffusealpha(0);
		PPS[i]:diffusealpha(0);
	end
end}
func {1204, function()
	for i = 1, 2 do
		PPL[i]:diffusealpha(1);
		PPS[i]:diffusealpha(1);
	end
end}

--setdefault {DISPLAY_CENTER_X, 'windowx', DISPLAY_CENTER_Y, 'windowy'}

local ok = {0, 0.5, 1.25, 2, 3, 3.25, 3.5, 3.75}
local tlqkf = false;
for i = 1492, 1520, 4 do
	local mod = 'noteskewx';
	local mod2 = 'skewx';
	for _,v in ipairs(ok) do
		if tlqkf then
			set {i+v, 100, mod, plr=3, -100, mod2}
		else
			set {i+v, -100, mod, plr=3, 100, mod2}
		end
		ease {i+v, 2, outExpo, 0, mod, plr=3, 0, mod2}
		tlqkf = not tlqkf;
	end
end

for i = 967, 1029, 2 do
	local bBeat = i%4==1;
	if bBeat then
		func_ease {i, 2, linear, sw+30, -30, 'bullet1:x'}
		func {i, function()
			bullet1:y(math.random(30, sh-30));
		end}
	else
		func_ease {i, 2, linear, -30, sw+30, 'bullet2:x'}
		func {i, function()
			bullet2:y(math.random(30, sh-30));
		end}
	end
end

func {804, function()
	for i = 0, #Fire do
		Fire[i]:hidden(0)
	end
end}

local fuck = {{1030.5, 0}, {1031.5, 2}, {1032.5, 0}, {1033.5, 2}, {1034, 1}, {1034.75, 3}, {1035.5, 0}, {1036, 2}, {1036.75, 3}, {1037.5, 1}};
for i = 1, #fuck do
	for j = 1, 5 do
		table.insert(fuck, {fuck[i][1]+(8*j), fuck[i][2]});
	end
end
for _,v in ipairs(bowerBGTrigger) do
	table.insert(fuck, {v, math.random(0,4)});
end
for _,v in ipairs(fuck) do
	local beat = v[1];
	local num = v[2];

	func {beat, function()
		Fire[num]:rotationz(0)
	end}
	func_ease {beat, 1.5, bounce, sh-50, scy-100, 'Fire['..num..']:y'}
	func_ease {beat+0.5, 0.5, inOutSine, 0, 180, 'Fire['..num..']:rotationz'}
end

func {1100, function()
	for i = 0, #Fire do
		Fire[i]:hidden(1)
	end
end}
ease {1142, 2, outQuad, 50, 'tipsy', 50, 'drunk'}

showSong(32, 1)
showSong(440, 2)
showSong(804, 3)
showSong(1204, 4)

_FakeCover:xywh(scx,scy,sw,sh);
_FakeCover:diffuse(0,0,0,0);

func {1204, function()
	TimeText:diffuse(1,1,1,1)
end}

func {1528, function()
	barBG:hidden(1)
	BG:diffuse(1,1,1,1)
end}
func {1532, function() barBG:hidden(0) end}
func {1536, function() barBG:hidden(1) end}
func {1540, function() barBG:hidden(0) end}
func {1544, function() barBG:hidden(1) end}
func {1556, function() BG:diffuse(0,0,0,1) end}

func {1564, function()
	CameraSpr:vibrate();
	Objects:hidden(1);
	bullet1:hidden(1);
	bullet2:hidden(1);
	_FakeCover:diffusealpha(1);
end}
func_ease {1564, 4, outQuad, 100, 0, function(p)
	CameraSpr:effectmagnitude(p,p,p);
end}

for i = 1461, 1523, 2 do
	if not is_easy_mode then
		set {i, 1000, 'dizzy', 50, 'shrinklinear', -250, 'longboys', -200, 'tiny'}
		ease{i, 2, outExpo, 0, 'dizzy', 0, 'shrinklinear', 25, 'longboys', 0, 'tiny'}
	else
		set {i, -100, 'tiny', -250, 'longboys'}
		ease{i, 2, outExpo, 0, 'tiny', 25, 'longboys'}
	end
end

for i = 725, 787, 2 do
	if is_easy_mode then set {i, -100, 'tiny'} else set {i, -200, 'tiny', 100, 'tipsy'} end
	ease {i, 2, outExpo, 0, 'tiny', 0, 'tipsy'}
end

for i = 1269, 1331, 2 do
	set {i, -100, 'tiny'}
	ease {i, 2, outExpo, 0, 'tiny'}
end

for i = 1528, 1552, 8 do
	set {i, 100, 'reverse', plr=3, 100, 'flip'}
	if i+4 ~= 1548 then
		set {i+4, 0, 'reverse', plr=3, 0,   'flip'}
	end
end

func_ease {344, 2, outExpo, 0, 1, 'HelpText:diffusealpha'}
func_ease {360, 2, outCirc, 1, 0, 'HelpText:diffusealpha'}
func_ease {1428, 32, inOutExpo, 0, 100, function(p)
	P1:GetChild('Judgment'):x2(p)
	P2:GetChild('Judgment'):x2(-p)
	P1:GetChild('Combo'):x2(p)
	P2:GetChild('Combo'):x2(-p)
end}

if window_movement then
	local x,y = DISPLAY_CENTER_X, DISPLAY_CENTER_Y+12;
	local maxW,maxH = DISPLAY:GetDesktopWidth(), DISPLAY:GetDesktopHeight()
	local flicker = 1;
	local ampX, ampY = 0, 0;
	--local dMultX, dMultY = 1152/DISPLAY:GetWindowWidth(), 864/DISPLAY:GetWindowHeight()
	local dMultX, dMultY = 1, 1;

	for _,v in ipairs(bumpbeats) do
		func_ease {v, 2, outExpo, 200, 0, function(p) ampX = p end}
	end

	if not is_easy_mode then
		local even = true;
		for i = 1461, 1492, 2 do
			if even then
				func_ease {i, 2, outExpo, 400 * dMultX, 0, function(p) ampX = p end}
			else
				func_ease {i, 2, outExpo, 200 * dMultY, 0, function(p) ampY = p end}
			end
			even = not even
		end

		for i = 1493, 1523-2, 4 do
			if even then
				func_ease {i, 2, outExpo, 0, 300 * dMultX, function(p) ampX = p end}
				func_ease {i+2, 2, outExpo, 300 * dMultX, 0, function(p) ampX = p end}
			else
				func_ease {i, 2, outExpo, 0, 200 * dMultY, function(p) ampY = p end}
				func_ease {i+2, 2, outExpo, 200 * dMultY, 0, function(p) ampY = p end}
			end
			even = not even
		end
	end

	perframe {1396, 1524-1396, function(b,p)
		if ampX ~= 0 then
			DISPLAY:SetWindowX(DISPLAY_CENTER_X + ampX * flicker);
		end
		if ampY ~= 0 then
			DISPLAY:SetWindowY((DISPLAY_CENTER_Y + 12) + ampY * flicker);
		end
		CameraSpr:xy(scx + (-ampX * flicker*0.8), scy + (-ampY * flicker * 0.8));
		flicker = -flicker;
	end}
	local speed = 4;
	perframe {1524, 1560-1524, function(b,p)
		local x,y = (math.sin(b*math.pi/speed) * ampX) * flicker, (math.cos(b*math.pi/speed) * ampY) * flicker;
		DISPLAY:SetWindowX(DISPLAY_CENTER_X + x);
		DISPLAY:SetWindowY((DISPLAY_CENTER_Y + 12) + y);
		CameraSpr:xy(scx + (-x * 0.8), scy + (-y * 0.8));
		flicker = -flicker;
	end}
	function lol(p) ampX = 300 * dMultX * p; ampY = 40 * dMultY * p; end
	func_ease {1524, 4, outQuad, 0, 1, lol}
	func_ease {1540, 8, inOutQuad, 1, 1.5, lol}
	func {1540, function() speed = 2 end}
	func {1548, function() speed = 1 end}
	func_ease {1552, 4, inExpo, 1.5, 0, lol}
end

card {0, 32, 'Intro', 0, {0.0, 0.0, 0.0}}
card {32, 344, 'Level 1 - Mr. sys', 4, {0.5, 0.5, 0.5}}
card {344, 428, 'Hardstyle', 6, {0.75, 0.5, 0.5}}
card {440, 756, 'Level 2 - Hunter Dog', 5, {1.0, 0.5, 0.0}}
card {756, 789, 'Hardstyle', 7, {1.0, 0.25, 0.0}}
card {804, 998, 'Level 3 - Bowser', 6, {0.0, 0.75, 0.0}}
card {998, 1109, 'Hardstyle', 8, {0.5, 0.75, 0.0}}
card {1109, 1178, 'Fake End', 2, {0.0, 0.0, 0.0}}
card {1184, 1188, 'YOU CANNOT BEAT US', 0, {0.0, 0.25, 0.0}}
card {1188, 1192, 'YOU CANNOT BEAT US', 0, {0.0, 0.75, 0.0}}
card {1192, 1196, 'YOU CANNOT BEAT US', 0, {0.5, 0.25, 0.0}}
card {1196, 1200, 'YOU CANNOT BEAT US', 0, {1.0, 0.5, 0.0}}
card {1200, 1201, 'YOU', 0, {0.0, 0.0, 0.0}}
card {1201, 1201.5, 'CAN', 0, {0.25, 0.25, 0.25}}
card {1201.5, 1202, 'NOT', 0, {0.5, 0.5, 0.5}}
card {1202, 1203, 'BEAT', 0, {0.75, 0.75, 0.75}}
card {1203, 1204, 'US', 0, {1.0, 1.0, 1.0}}
card {1204, 1396, 'Level 4', 9, {1,1,1}}
card {1396, 1460, 'Buildup', 4, {0.25, 0.25, 0.25}}
card {1460, 1524, 'Final Stretch', 10, {1,0,0}}
card {1524, 1528, 'Aim Your Zapper Gun', 0, {1,1,1}}
card {1528, 1532, 'YOU CANNOT BEAT US', 0, {1,0,0}}
card {1532, 1536, 'Even with your robot partner?', 0, {1,1,1}}
card {1536, 1540, 'YOU CANNOT BEAT US', 0, {1,0,0}}
card {1540, 1544, 'Discover New Worlds!', 0, {1,1,1}}
card {1544, 1548, 'YOU CANNOT BEAT US', 0, {1,0,0}}
card {1548, 1552, 'SCORE ONE MILLION', 0, {1,1,1}}
card {1552, 1556, 'YOU CANNOT BEAT US', 0, {1,0,0}}
card {1556, 1560, 'We Are Nintendo', 0, {1,1,1}}
card {1560, 1564, 'YOU CANNOT BEAT US', 9e9, {1,0,0}}