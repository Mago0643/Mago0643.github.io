xero()
if not Shader then SCREENMAN:SystemMessage("Your build doesn't have shader support. Please upgrade to alpha V or later!") return Def.ActorFrame{} end
return Def.ActorFrame {
	LoadCommand = function(self)
		-- judgment / combo proxies
		for pn = 1, 2 do
			setupJudgeProxy(PJ[pn], P[pn]:GetChild('Judgment'), pn)
			setupJudgeProxy(PC[pn], P[pn]:GetChild('Combo'), pn)
		end
		-- player proxies
		for pn = 1, #PP do
			PP[pn]:SetTarget(P[pn])
			P[pn]:hidden(1)
		end
		-- set default mods/notitg mod conversions
		NotITGMods(true)
		setdefault {100, 'modtimer', 100, 'disablemines'}
		-- funy arow jigles go here

		local function camZoom(beat, len, ease, zoom)
			func {beat, len, ease, zoom, 1, "GlitchSprite:zoom"}
		end

		local function glitch(beat, len, ease, amp, zoom)
			func {beat, len, ease, amp, 0, function(p)
				Glitch:uniform1f('amp', p);
			end}
			camZoom(beat, len, ease, zoom);
			func {beat, len, ease, amp * 100, 0, function(p)
				Abberation:uniform1f('DISTORTION_AMOUNT', p);
			end}
			func {beat, len, ease, .5, 0, function(p) Bloom:uniform1f('intensity', p) end}
			if beat >= 532 then
				func {beat, len*2, ease, 2, 0, 'ScreenSprite:diffusealpha'}
				func {beat, len, ease, 1.2, 0.98, 'ScreenSprite:zoom'}
				func {beat, len*2, ease, 1, 0, function(p) BloomSprite:diffuse(1,1-p,1-p,1) end}
			end
		end

		func {184, 4, outExpo, sh+50, sh - 100, 'score1:y'}
		func {200.5, function()
			score1:visible(false)
			score2:visible(true)
		end}
		func {218, function()
			score2:visible(false)
			score3:visible(true)
		end}
		func {232, function()
			score3:visible(false);
			score4:visible(true);
		end}
		func {250, function()
			score4:visible(false);
			score5:visible(true)
		end}
		func {280, function()
			score6:visible(true)
			score5:visible(false)
		end}
		func {296, function()
			score6:visible(false)
			score7:visible(true)
		end}
		func {306, function()
			score7:visible(false)
			score8:visible(true)
		end}
		func {314, 4, inBack, sh - 100, sh + 50, 'score8:y'}

		for i = 146, 158, 4 do
			glitch(i, 4, outExpo, 0.01, 1.075);
		end
		glitch(164, 4, outExpo, 0.01, 1.075);
		--[[set {187.5, 200, 'beat', -50, 'beatmult'}
		set {313.5, 0, 'beat', 0, 'beatmult'}]]

		local godbeats = xero.loadscript('lua/godbeats.lua');
		local fuck = xero.loadscript('lua/fuck.lua');
		for _,v in ipairs(godbeats) do
			glitch(v[1], 4, outExpo, 0.01, 1.075)
			set {v[1], -10, 'tiny'}
			ease {v[1], 4, outExpo, 0, 'tiny'}
		end

		for _,v in ipairs(fuck) do
			local even = _ % 2 == 0;
			glitch(v[1], 2, outExpo, 0.025, 1.1)
			set {v[1], even and 200 or -200, 'tipsy', even and 200 or -200, 'drunk'}
			ease {v[1], 2, outExpo, 0, 'tipsy', 0, 'drunk'}
		end

		ease {134, 2, inExpo, 100, 'drunk'}
		ease {140, 1.5, inExpo, 500, 'x', -100, 'flip', -500, 'drunk'}
		ease {141.5, 2, outExpo, 0, 'drunk', 0, 'x', 0, 'flip'}

		glitch(597, 8, outExpo, 0.025, 1.075)

		--[[func {572.5, 4, outExpo, 0.5, 1, 'Bat_Outta_Hell:zoom'}
		func {572.5, 4, outExpo, .75, 0, 'Bat_Outta_Hell:diffusealpha'}]]

		set {502.5, 200, 'beat'}
		set {514.5, 0, 'beat'}
		ease {515, 2, outExpo, 100, 'drunk'}
		ease {517, 2, inExpo, 0, 'drunk'}
		set {518.5, 200, 'beat'}
		set {564.5, 0, 'beat'}

		for i = 503, 531 do
			if i ~= 516 and i ~= 517 and i ~= 518 then
				camZoom(i, 2, outExpo, 1.075)
			end
		end

		set {530.5, 0, 'beat'}
		set {532.5, 200, 'beat'}
		ease {531, 1, outExpo, -100, 'drunk'}
		ease {532, 1, inExpo, 0, 'drunk'}
		ease {565, 2, outExpo, 20, 'digital', 20, 'sawtooth'}
		ease {597, 4, outExpo, 0, 'digital', 0, 'sawtooth'}
		ease {617.5, 4, outQuad, -200, 'flip', math.rad(-180)*100, 'confusionoffset'}
		ease {617.5, 2, inBack, 700, 'y'}

		local data = {
			{5.5, "But you have to keep going,"},
			{12, "Keep moving on."},
			{14, "...and don't you ever look back."},
			{16, ""}
		};
		for _,v in ipairs(data) do
			func {v[1], function()
				lyrics:settext(v[2])
			end}
		end
	end,
	-- funy scren budies go here
	Def.Sprite {
		Name = 'ScreenSprite',
		InitCommand = function(self)
			sprite(self)
			self:diffuse(1,0,0,0):zoom(1):vibrate()
		end,
		OnCommand = function(self)
			aftsprite(AbbAST, self)
		end,
	},
	Def.ActorProxy { Name = 'PJ[1]' },
	Def.ActorProxy { Name = 'PP[1]' },
	Def.ActorProxy { Name = 'PP[2]' },
	Def.ActorProxy { Name = 'PJ[1]' },
	Def.ActorProxy { Name = 'PJ[2]' },
	Def.ActorProxy { Name = 'PC[1]' },
	Def.ActorProxy { Name = 'PC[2]' },
	Def.BitmapText {
		Name = "lyrics",
		Text = "",
		InitCommand = function(self)
			self:xy(scx,scy + 100):diffuse(0,1,0,1):zoom(1.25);
		end
	},
	Def.Sprite {
		Texture = "score1.png",
		Name = "score1",
		InitCommand = function(self)
			xero();
			self:zoom(0.5):xy(scx,sh + 50)
		end
	},
	Def.Sprite {
		Texture = "score2.png",
		Name = "score2",
		InitCommand = function(self)
			xero();
			self:zoom(0.45):xy(scx,sh - 100):visible(false)
		end
	},
	Def.Sprite {
		Texture = "score3.png",
		Name = "score3",
		InitCommand = function(self)
			xero();
			self:zoom(0.45):xy(scx,sh - 100):visible(false)
		end
	},
	Def.Sprite {
		Texture = "score4.png",
		Name = "score4",
		InitCommand = function(self)
			xero();
			self:zoom(0.45):xy(scx,sh - 100):visible(false)
		end
	},
	Def.Sprite {
		Texture = "score5.png",
		Name = "score5",
		InitCommand = function(self)
			xero();
			self:zoom(0.45):xy(scx,sh - 100):visible(false)
		end
	},
	Def.Sprite {
		Texture = "score6.png",
		Name = "score6",
		InitCommand = function(self)
			xero();
			self:zoom(0.45):xy(scx,sh - 100):visible(false)
		end
	},
	Def.Sprite {
		Texture = "score7.png",
		Name = "score7",
		InitCommand = function(self)
			xero();
			self:zoom(0.45):xy(scx,sh - 100):visible(false)
		end
	},
	Def.Sprite {
		Texture = "score8.png",
		Name = "score8",
		InitCommand = function(self)
			xero();
			self:zoom(0.45):xy(scx,sh - 100):visible(false)
		end
	},
	Def.ActorScreenTexture {
		Name = 'GlitchAST',
		InitCommand = function(self)
			aft(self)
		end,
	},
	Def.Sprite {
		Name = 'GlitchSprite',
		Frag = "shaders/glitch.frag",
		InitCommand = function(self)
			sprite(self)
			Glitch = self:GetShader();
			Glitch:uniform1f('amp', 0);
		end,
		OnCommand = function(self)
			aftsprite(GlitchAST, self)
		end,
	},
	Def.ActorScreenTexture {
		Name = 'AbbAST',
		InitCommand = function(self)
			aft(self)
		end,
	},
	Def.Sprite {
		Name = 'AbbSprite',
		Frag = "shaders/abberation.frag",
		InitCommand = function(self)
			sprite(self)
			Abberation = self:GetShader();
			Abberation:uniform1f('DISTORTION_AMOUNT', 0);
		end,
		OnCommand = function(self)
			aftsprite(AbbAST, self)
		end,
	},
	Def.ActorScreenTexture {
		Name = 'ScreenAST',
		InitCommand = function(self)
			aft(self)
		end,
	},
	Def.ActorScreenTexture {
		Name = 'BloomAST',
		InitCommand = function(self)
			aft(self)
		end
	},
	Def.Sprite {
		Name = 'BloomSprite',
		Frag = "shaders/bloom.frag",
		InitCommand = function(self)
			sprite(self);
			Bloom = self:GetShader();
			Bloom:uniform1f('intensity', 0);
		end,
		OnCommand = function(self)
			aftsprite(BloomAST, self);
		end
	}
}
