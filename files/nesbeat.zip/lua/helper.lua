function addUselessLyrics()
  local fuck = {
    {141, "WITH"}, {141.5, "WITH YOUR"}, {142, "WITH YOUR TEN"}, {143, "WITH YOUR TENDO"}, {144, ""},
    {212.5, "NIN"}, {213, "NINTEN"}, {213.5, "NINTENNIN"}, {214, "NINTENNIN\nBEAT"}, {215, "NINTENNIN\nBEAT US"},
  };
  for i = 1508, 1520, 4 do
    table.insert(fuck, {i, 'YOU'});
    table.insert(fuck, {i+1, 'YOU CAN'});
    table.insert(fuck, {i+1.5, 'YOU CANNOT'});
    table.insert(fuck, {i+2, 'YOU CANNOT BEAT'});
    table.insert(fuck, {i+3, 'YOU CANNOT BEAT US'});
  end
  return fuck;
end